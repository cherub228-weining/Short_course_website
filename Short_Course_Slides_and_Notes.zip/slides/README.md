# Short-course slides

Use `Causal_SDLP_ECFIN_Enriched.pdf` and its LaTeX source for the 19 November 2026 course. This edition has 81 slides, including optional exercises and appendix material. The matching instructor script gives a session-by-session route.

The `figures/` assets reproduce Figures 3 and 4 of the authors' 8 November 2026 manuscript and are the same assets used in the prepared research seminar. Compile the slide source from this directory.

`Causal_SDLP_ECFIN_Three_Hour_Lecture.tex` and `Causal_SDLP_ECFIN_Slides.pdf` are preserved original versions. The organiser's current 13:30–17:00 agenda takes precedence over their earlier timing.

The identification review adds six teaching slides, two technical appendices and two reference slides. Detailed derivations and worked checks are in `../notes/LP_Identification_Comprehensive_Notes.pdf`, with an editable LaTeX source. The instructor script gives a timed core route through the expanded material.
