# Causal state-dependent local projections

19 November 2026 · Brussels · 13:30–17:00 CET (12:30–16:00 UK).

- 13:30–13:45: Welcome and Introduction
- 13:45–14:30: Identification and Causal Responses
- 14:30–15:15: Causal State-dependent Local Projections
- 15:15–15:30: Break
- 15:30–16:15: Estimation and Inference
- 16:15–16:45: Practical R Application
- 16:45–17:00: Discussion and Q&A

Joining details are supplied by the organiser.
