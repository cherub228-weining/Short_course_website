# Numerical invariants of the teaching estimator. Run from repository root.
source("code/R/exercise_setup.R")
stopifnot(nrow(d)==24000, length(unique(d$t))==240,
          !anyDuplicated(d[c("id","t")]))
f4 <- estimate_horizon(4,Jset=7,bandwidth=4)
f8 <- estimate_horizon(4,Jset=7,bandwidth=8)
stopifnot(f4$n==23600, f4$dates==236,
          max(abs(f4$b-f8$b))<1e-12,
          max(abs(f4$V-f8$V))>1e-10)
# Full-regressor sandwich versus a separately computed FWL sandwich.
B <- make_basis(d$z,7); Q <- B*d$x
W <- cbind(d$ylag,1); D <- cbind(Q,W)
full <- ols_date_hac(D,d$y,d$t,4)
Qt <- qr.resid(qr(W),Q); yt <- qr.resid(qr(W),d$y)
fwl <- ols_date_hac(Qt,yt,d$t,4)
stopifnot(max(abs(full$b[1:7]-fwl$b))<1e-10,
          max(abs(full$V[1:7,1:7]-fwl$V))<1e-9)
# State contrasts are invariant to a level shift in a full B-spline basis.
fit <- estimate_horizon(0,Jset=7)
P <- predict(fit$B,newx=c(0,.75))
stopifnot(max(abs(rowSums(P)-1))<1e-12)
old <- infer_contrast(fit)$estimate
fit$b <- fit$b+2
stopifnot(abs(infer_contrast(fit)$estimate-old)<1e-10)
shift <- nonlinear_shift_demo()
stopifnot(abs(shift$discrepancy-.25)<1e-12,
          abs(shift$finite_shift-shift$MC_shift)<.03)
cat("Passed: timing, horizon sample, bandwidth invariance, FWL covariance,\n",
    "normalization invariance and finite-shift target.\n")
