# Causal state-dependent local projections

Public teaching materials for the short course and separate research talk by
Weining Wang and Xiyu Jiao. Start with START_HERE.txt and Local_Projections.Rproj.

## Run from this folder

```r
source("code/R/check_setup.R")
source("exercises/participant_template.R")
source("exercises/instructor_solutions.R")
source("code/R/run_course.R")
```

The participant tasks use base R and splines. The optional R Markdown notebook
uses rmarkdown and knitr. The full demo writes synthetic data to data/generated
and results to output_R_paper. Advanced examples live in advanced_demo; run their
setup check from that directory and install the packages listed there.

Materials copied from the 9 November 2026 Short_course repository snapshot.
The public packaging and participant navigation were added on 13 November 2026.
Research talk, short-course slides, exercises, worked answers,
R code, figures, reading list, identification notes and editable LaTeX are included.
The full research manuscript and firm-level data are outside this teaching bundle.
No new redistribution licence is assigned.
