# Short-course slides

Use Causal_SDLP_ECFIN_Enriched.pdf for the 23 November 2026 DG ECFIN course.
This is the 105-slide edition expanded on 16 November with DG ECFIN defence
R&D, uncertainty and labour-supply cases, worked examples and exercises.
The deck uses section headings. Compile the LaTeX source in this directory;
all required figure assets are included. The other lecture files are historical.

The companion notes cover LP identification in more detail. The constructed
arithmetic examples are in ../code/ECFIN_worked_examples.R. Run that file in
a fresh R process so its objects do not replace the core simulation objects.
Use the organiser's latest instructions for session times and joining details.
