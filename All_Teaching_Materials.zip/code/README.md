# R practical

Run from the repository root with base R and the recommended `splines` package.

- `R/exercise_setup.R`: shared simulator and estimation/inference functions. Sourcing creates a synthetic baseline panel but does not run the full horizon loop.
- `R/course_demo.R`: full demonstration, horizons 0–8, AIC over `4:20`, bands and contrasts, sensitivity and optional identification examples.
- `R/run_course.R`: runs the demonstration and exports the synthetic panel.
- `../exercises/instructor_solutions.R`: timed-handout answers using AIC over `4:10`.
- `../scripts/check_course.R`: numerical checks of the calculation.

The baseline has 100 units and 240 dates. Its true response is `0.6^h * (1-z^2)`. The optional endogenous-state design changes the state transition and retains fixed propagation. The nonlinear-shock helper contrasts an LP slope with a finite-shift causal target. All data are synthetic.

The covariance sums scores by date and applies Bartlett HAC. The Gaussian state-grid band is for a single horizon, conditional on the selected basis. Its asymptotic interpretation requires approximation bias and regularity conditions; AIC alone does not establish coverage. It is not a joint horizon band. The code does not implement fixed effects, IV inference or generated-shock corrections.
