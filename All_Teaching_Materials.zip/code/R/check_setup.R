# Run from the extracted pack root, or open Local_Projections.Rproj first.
stopifnot(file.exists("code/R/exercise_setup.R"))
if (!requireNamespace("splines", quietly=TRUE)) stop("Install R with its recommended splines package.")
source("code/R/exercise_setup.R")
stopifnot(nrow(d)==24000L, length(unique(d$id))==100L,
          length(unique(d$t))==240L, !anyDuplicated(d[c("id","t")]))
fit <- estimate_horizon(0,Jset=4)
stopifnot(all(is.finite(infer_contrast(fit)$estimate)))
cat("SETUP CHECK PASSED — open exercises/participant_template.R.\n")
