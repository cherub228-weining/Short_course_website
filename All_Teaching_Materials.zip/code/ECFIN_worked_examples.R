# DG ECFIN course: self-contained numerical worked examples
# All numerical inputs are constructed. This is not an empirical replication.
# Base R only. Run: source("code/ECFIN_worked_examples.R")

# 1. Shock scaling: units are percentage points of GDP.
beta <- 1.40
se_beta <- .50
delta <- c(1, .1, .005)
scaling <- data.frame(
  shock_pp = delta,
  response_pp = delta * beta,
  lower_95 = delta * beta - 1.96 * abs(delta) * se_beta,
  upper_95 = delta * beta + 1.96 * abs(delta) * se_beta
)
print(scaling)

# 2. LP-IV normalisation. D is in percentage points.
first_stage_moment <- .08
reduced_form_moment <- -.016
theta <- reduced_form_moment / first_stage_moment
effect_25bp <- .25 * theta
print(c(theta_per_pp = theta, effect_25bp = effect_25bp))
stopifnot(abs(effect_25bp + .05) < 1e-12)
# Rescaling the instrument leaves the point estimate unchanged.
stopifnot(abs((100 * reduced_form_moment) /
             (100 * first_stage_moment) - theta) < 1e-12)

# 3. Contrasts need cross-state covariance.
gA <- -.50
gB <- -.20
covAB <- c(0, .030)
contrast <- gA - gB
contrast_se <- sqrt(.20^2 + .20^2 - 2 * covAB)
print(data.frame(covAB, contrast, contrast_se,
                 lower_95 = contrast - 1.96 * contrast_se,
                 upper_95 = contrast + 1.96 * contrast_se))

# 4. Common score component.
N <- 100
print(c(correct_variance = 1 + 4 / N,
        independence_variance = (1 + 4) / N))

# 5. Calendar-matched leads in a panel containing a gap.
d <- data.frame(id = c(1,1,1,1,2,2,2),
                year = c(2000,2001,2003,2004,2000,2001,2002),
                y = c(10,11,13,14,20,21,22))
key <- paste(d$id, d$year, sep = ":")
stopifnot(!anyDuplicated(key))
h <- 1
d$y_lead <- d$y[match(paste(d$id, d$year+h, sep = ":"), key)]
print(d)
# For unit 1 in 2001, the next calendar year is missing.
stopifnot(is.na(d$y_lead[d$id == 1 & d$year == 2001]))

# 6. Response kernel and shock path (linear, invariant dynamics).
# psi is a LEVEL response; do not sum it again to get a level response.
psi <- c(.2, .5, .8, .6, .3)
scenario_response <- function(psi, delta) {
  stopifnot(length(psi) == length(delta))
  vapply(seq_along(psi)-1L, function(h) {
    j <- 0:h
    sum(psi[h-j+1] * delta[j+1])
  }, numeric(1))
}
one_off <- scenario_response(psi, c(.1,0,0,0,0))
repeated <- scenario_response(psi, c(.1,.1,.1,0,0))
print(data.frame(h = 0:4, one_off, repeated))
stopifnot(max(abs(repeated - c(.02,.07,.15,.19,.17))) < 1e-12)

# Optional plot in the current R graphics device.
matplot(0:4, cbind(one_off,repeated), type="b", lty=c(1,2),
        pch=c(16,17), col=c("#007D82","#C66B35"),
        xlab="Horizon", ylab="Level response",
        main="Constructed single and repeated shocks")
legend("topleft", c("One shock","Three shocks"), lty=c(1,2),
       pch=c(16,17), col=c("#007D82","#C66B35"), bty="n")


