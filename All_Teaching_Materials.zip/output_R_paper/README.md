# Synthetic course results

All CSVs and plots here use simulated data. Run `Rscript code/R/run_course.R` and `Rscript exercises/instructor_solutions.R` from the repository root to regenerate them. The handout answers use J=4:10; the full horizon demonstration uses J=4:20. These files are separate from the manuscript Monte Carlo tables and Compustat empirical figures.
