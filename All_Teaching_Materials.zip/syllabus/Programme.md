# Causal state-dependent local projections

23 November 2026 · Brussels

- Welcome and Introduction
- Identification and Causal Responses
- Causal State-dependent Local Projections
- Break
- Estimation and Inference
- Practical R Application
- Discussion and Q&A

Use the organiser’s latest instructions for times and joining details.
