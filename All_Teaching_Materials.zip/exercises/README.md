# Participant and instructor materials

The seven-page `R_Exercises_Handout.pdf` is a printable participant copy with answer spaces. The core practical lasts 30 minutes; the horizon, bandwidth, endogenous-state and nonlinear-shock extensions are optional.

Extract `R_Exercises_Participant_Pack.zip`, open R in its root folder and work through `exercises/participant_template.R`. The pack contains the unanswered handout, setup code and the annotated reading list in `syllabus/Reading_List.pdf` (with its LaTeX source).

Instructor files are separate: `R_Exercises_Solutions.pdf` gives worked answers and `instructor_solutions.R` regenerates the numerical results and comparison plot. Run from the full repository root. The timed exercise uses AIC candidates `4:10`, while the full demonstration uses `4:20`; their selected dimensions and numerical results can differ.
