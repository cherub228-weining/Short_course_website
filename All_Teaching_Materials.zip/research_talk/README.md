# One-hour research talk

Research slides (PDF and LaTeX), figure assets and an outline. Prepared version: 8 November 2026. The deck has
40 slides including discussion and backups; allow 50 minutes plus 10 minutes Q&A.

Compile the LaTeX from this directory so figures/ resolves. The manuscript and
raw empirical replication data are not part of this teaching download.
