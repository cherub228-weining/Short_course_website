# Research talk outline

50 minutes of presentation, followed by 10 minutes of discussion. Ten backup slides are available for questions.

| Time | Slide | Topic |
|---|---:|---|
| 00:00–00:45 | 1 | Causal State-Dependent Local Projections |
| 00:45–02:15 | 2 | Motivation: a widely used tool |
| 02:15–03:45 | 3 | Gap in the literature |
| 03:45–05:15 | 4 | This paper |
| 05:15–07:15 | 5 | Causal IRF: the object of interest |
| 07:15–09:15 | 6 | Three stylised DGPs |
| 09:15–10:15 | 7 | Summary: what LPs recover |
| 10:15–13:15 | 8 | Identification: the key condition |
| 13:15–15:15 | 9 | Where A3 holds (I): fixed types and HANK |
| 15:15–17:15 | 10 | Where A3 holds (II): macro-finance panel VAR |
| 17:15–18:45 | 11 | Where A3 fails |
| 18:45–21:15 | 12 | Does the choice of state matter? |
| 21:15–24:15 | 13 | Why standard linear LPs miss the function |
| 24:15–25:45 | 14 | Proposed solution: sieve LP |
| 25:45–28:15 | 15 | Inference: state-dependent convergence rates |
| 28:15–29:45 | 16 | Inference: pointwise and uniform theory |
| 29:45–31:15 | 17 | Inference: feasible HAC covariance |
| 31:15–32:45 | 18 | Inference: a studentized uniform band |
| 32:45–34:15 | 19 | Simulation: sieve vs. linear across horizons |
| 34:15–35:45 | 20 | Intermediate shocks and precision |
| 35:45–36:45 | 21 | Selector comparison |
| 36:45–38:45 | 22 | Empirical application: firm investment |
| 38:45–41:45 | 23 | Firm investment IRFs: linear vs. nonlinear |
| 41:45–42:45 | 24 | Firm investment IRFs: interpretation |
| 42:45–44:45 | 25 | Differential responses across D2D |
| 44:45–46:15 | 26 | Differential responses: takeaways |
| 46:15–47:15 | 27 | Aggregate implications |
| 47:15–49:15 | 28 | Aggregate implications: takeaways |
| 49:15–50:00 | 29 | Conclusion |
| 50:00–60:00 | 30 | Discussion |

## Backup slides

- 31. Appendix: identification proof sketch
- 32. Appendix: Proposition 2 proof idea
- 33. Appendix: numerical illustrations
- 34. Appendix: impact coverage with AIC
- 35. Appendix: coverage and RIMSE at later horizons
- 36. Appendix: economic interpretation of A3
- 37. Appendix: HA/HANK in more detail
- 38. Appendix: macro-finance VAR in more detail
- 39. Appendix: measured shocks and controls
- 40. Appendix: fixed effects and normalization
