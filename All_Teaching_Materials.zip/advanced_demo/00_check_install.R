# =====================================================================
# 00_check_install.R  --  run this BEFORE the course (takes ~10 seconds)
# Set the working directory to the R_code_demo folder, then:
#   source("00_check_install.R")
# It checks R, the packages and the course files, then runs a tiny
# estimation. It prints "ALL CHECKS PASSED" if you are ready.
# =====================================================================

ok <- TRUE
report <- function(pass, msg) {
  cat(if (pass) "  [ok]     " else "  [FAILED] ", msg, "\n", sep = "")
  if (!pass) ok <<- FALSE
}
cat("\nCourse set-up check\n")

# 1. R version
report(getRversion() >= "4.1.0",
       paste0("R version ", getRversion(), " (need 4.1.0 or later)"))

# 2. Packages
needed  <- c("mvtnorm", "glmnet", "ggplot2")
missing <- needed[!vapply(needed, requireNamespace, logical(1), quietly = TRUE)]
for (p in setdiff(needed, missing)) {
  report(TRUE, paste0("package ", p, " ", as.character(utils::packageVersion(p))))
}
for (p in missing) report(FALSE, paste0("package ", p, " is not installed"))
if (length(missing) > 0) {
  cat("\n  Install the missing packages with:\n",
      '    install.packages(c(', paste0('"', missing, '"', collapse = ", "), '))\n',
      "  If this fails behind a firewall or proxy, ask your IT support to\n",
      "  install them, or use the cloud fallback described in README.txt.\n", sep = "")
}

# 3. Course files
files <- c("00_setup.R", "functions/uniform_bands_FE.R", "functions/simulate_DGPs.R",
           "functions/NL_helper_functions.R", "functions/course_helpers.R")
found <- file.exists(files)
report(all(found), if (all(found)) "course files found" else
       paste("missing:", paste(files[!found], collapse = ", "),
             "-- is the working directory R_code_demo?"))

# 4. A tiny end-to-end run (only if everything above passed)
if (ok) {
  test <- try({
    suppressMessages(source("00_setup.R"))
    sim <- simulate_DGP_paranhos(N = 20, T = 60, H = 1, g_spec = "quadratic",
                                 theta = 0, alpha_mode = "zero", seed = 1,
                                 make_pdata = FALSE, out = "panel")
    fit <- gauss_bootstrap_ucb(data = sim$panel_df, Y_var = "Y", X_var = "X",
                               Z_var = "Z", W_vars = "Y_lag", basis = "spline",
                               J_method = "manual", J = 4, H = 1, M = 200)
    tab <- band_at_horizon(fit, h = 0)
    print(plot_irf(tab, x = "z"))
    nrow(tab) > 0
  }, silent = TRUE)
  report(isTRUE(test), if (isTRUE(test)) "test estimation and plot ran" else
         paste("test estimation failed:", conditionMessage(attr(test, "condition"))))
}

cat(if (ok) "\nALL CHECKS PASSED -- you are ready for the course.\n\n"
    else "\nSOME CHECKS FAILED -- please fix the items above before the course.\n\n")
