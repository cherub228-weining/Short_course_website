# -------------------------------------------------------------------
# Simulate the DGP (dynamic panel) from Paranhos (2025) but with the individual fixed effect
# -------------------------------------------------------------------
# Y_{it} = g_{0,z}(Z_{it}) * X_t + rho_y * Y_{i,t-1} + alpha_i +
#          sigma_i * (1 + theta^2)^(-1/2) * (eta_{it} + theta * eta_{i,t-1})
#
# with:
#   Z_{it} = mu_i + xi_{it},  mu_i ~ i.i.d. N(0, sigma_mu2)
#   xi_{it} = rho_xi * xi_{i,t-1} + sqrt(1 - rho_xi^2) * v_{it}, v_{it} ~ N(0,1)
#   X_t ~ i.i.d. N(0, Var(X_t))
#   eta_{it} ~ i.i.d. N(0, var_eta), entering via MA(1) with parameter theta
#   epsilon_{it} ~ i.i.d. N(0, var_eps), entering inside g_{0,z}
#   alpha_i ~ i.i.d. N(0, var_alpha)  (individual fixed effect; can be turned off)
#   hetero: sigma_i^2 ~ i.i.d. (1 + ChiSq_1) / 2; or one: sigma_i = 1
#
# Four choices for g_{0,z}(Z):
#   "linear"    : g_{0,z}(Z) = Z + epsilon
#   "piecewise" : g_{0,z}(Z) = 1{Z>0} * Z + epsilon
#   "quadratic" : g_{0,z}(Z) = 1 - Z^2 + epsilon (hump-shaped)
#   "cubic"     : g_{0,z}(Z) = 0.5 * Z + 0.3 * Z^2 - 0.25 * Z^3 + epsilon
#   "fourier"   : g_{0,z}(Z) = 0.8 * sin(2 * pi * Z) + 2 * cos(2 * pi * Z) - 0.5 * sin(4 * pi * Z) + cos(4 * pi * Z) + epsilon
#
# The first `burnin` periods are discarded. We also simulate an additional H
# periods so we can construct forward (lead) variables Z_{i, t+h} and X_{t+h}
# for h = 1, ..., H. Default H = 12.
# -------------------------------------------------------------------

simulate_DGP_paranhos <- function(
    N,
    T,
    g_spec                 = c("linear", "piecewise", "quadratic", "cubic", "fourier"),
    rho_y                  = 0.8,
    rho_xi                 = 0.4,
    theta                  = 0.4,
    burnin                 = 500,
    var_eps                = 8,    # Var(epsilon_{it})
    var_eta                = 24,   # Var(eta_{it})
    sigma_X2               = 1,    # Var(X_t)
    sigma_mu2              = 3,    # Var(mu); mu is individual component in Z_{it}
    alpha_mode             = c("normal", "zero"), # normal: alpha_i ~ N(0,var_alpha); zero: alpha_i = 0
    var_alpha              = 1,                  # Var(alpha_i) when alpha_mode="normal"
    sigma_mode             = c("hetero", "one"), # hetero: original sigma_i, one: sigma_i = 1
    H                      = 12,   # number of forward horizons to provide
    fourier_range          = NULL, # optional fixed c(zmin, zmax) used when g_spec = "fourier"
    seed                   = NULL,
    out                    = c("both", "panel", "wide"),
    make_pdata             = TRUE,   # build plm::pdata.frame if plm is installed
    include_leads_in_panel = TRUE  # add Z_leadh/X_leadh columns to panel_df
) {
  if (!is.null(seed)) set.seed(seed)
  g_spec     <- match.arg(g_spec)
  sigma_mode <- match.arg(sigma_mode)
  alpha_mode <- match.arg(alpha_mode)
  out        <- match.arg(out)
  H          <- as.integer(H)
  if (H < 0) stop("H must be >= 0")
  
  N  <- as.integer(N)
  T  <- as.integer(T)
  TT <- T + as.integer(burnin) + H  # extend by H so leads are available
  
  # --- Common shock X_t ~ N(0,sigma_X2) ---
  X <- rnorm(TT, 0, sqrt(sigma_X2))
  
  # --- Individual effects mu_i ~ N(0, sigma_mu2) ---
  mu <- rnorm(N, 0, sqrt(sigma_mu2))
  
  # --- AR(1) for xi_{it}; stationary init xi_{i0} ~ N(0,1) ---
  xi      <- matrix(NA_real_, nrow = N, ncol = TT)
  xi0     <- rnorm(N, 0, 1)
  v_innov <- matrix(rnorm(N * TT, 0, 1), nrow = N, ncol = TT)
  
  xi[, 1] <- rho_xi * xi0 + sqrt(1 - rho_xi^2) * v_innov[, 1]
  if (TT >= 2) {
    for (t in 2:TT) {
      xi[, t] <- rho_xi * xi[, t - 1] + sqrt(1 - rho_xi^2) * v_innov[, t]
    }
  }
  
  # --- Z_{it} = mu_i + xi_{it} ---
  Z <- sweep(xi, 1, mu, `+`)
  
  # --- epsilon_{it} ~ N(0, var_eps) ---
  eps <- matrix(rnorm(N * TT, 0, sqrt(var_eps)), nrow = N, ncol = TT)
  
  # Fourier g_{0,z}(z), J = 4 ---
  g_fun <- function(z) {
      0.8 * sin(2 * pi * z) +
      2.0 * cos(2 * pi * z) -
      0.5 * sin(4 * pi * z) +
      1.0 * cos(4 * pi * z)
  }
  
  # map Z_it to [0,1] before fourier g(z) ---
  keep_idx <- (burnin + 1):(burnin + T)
  if (is.null(fourier_range)) {
    Zmin <- min(Z[, keep_idx, drop = FALSE])
    Zmax <- max(Z[, keep_idx, drop = FALSE])
  } else {
    if (length(fourier_range) != 2L || any(!is.finite(fourier_range))) {
      stop("fourier_range must be NULL or a finite numeric vector of length 2.")
    }
    Zmin <- min(fourier_range)
    Zmax <- max(fourier_range)
    if (Zmax <= Zmin) stop("fourier_range must satisfy zmax > zmin.")
  }
  Z_unit <- (Z - Zmin) / (Zmax - Zmin)
  
  gZ_fourier <- g_fun(Z_unit)  # N x TT
  
  # --- g_{0,z}(Z_{it}) ---
  gZ <- switch(
    g_spec,
    "linear"    = Z + eps,
    "piecewise" = (Z > 0) * Z + eps,
    "quadratic" = 1 - Z^2 + eps,
    "cubic"     = 0.5 * Z + 0.3 * Z^2 - 0.25 * Z^3 + eps,
    "fourier"   = gZ_fourier + eps
  )
  
  # --- individual fixed effects alpha_i ---
  if (alpha_mode == "normal") {
    alpha <- rnorm(N, mean = 0, sd = sqrt(var_alpha))
  } else {
    alpha <- rep(0, N)
  }
  
  # --- Heteroskedastic or homoskedastic sigma_i ---
  if (sigma_mode == "hetero") {
    sigma2 <- (1 + rchisq(N, df = 1)) / 2
    sigma  <- sqrt(sigma2)
  } else {
    sigma2 <- rep(1, N)
    sigma  <- rep(1, N)
  }
  
  # --- MA(1): u_{it} = eta_{it} + theta * eta_{i,t-1} ---
  eta     <- matrix(rnorm(N * (TT + 1), 0, sqrt(var_eta)), nrow = N, ncol = TT + 1)
  scale_u <- 1 / sqrt(1 + theta^2)
  
  u_raw    <- matrix(NA_real_, nrow = N, ncol = TT)
  e_scaled <- matrix(NA_real_, nrow = N, ncol = TT)
  err      <- matrix(NA_real_, nrow = N, ncol = TT)
  
  # --- Recursion for Y including the extra H periods ---
  Y <- matrix(NA_real_, nrow = N, ncol = TT)
  Y_prev <- rep(0, N)
  
  for (t in 1:TT) {
    u_raw[, t]    <- eta[, t + 1] + theta * eta[, t]
    e_scaled[, t] <- scale_u * u_raw[, t]
    err[, t]      <- sigma * e_scaled[, t]
    
    # gZ * X[t]
    gx_t   <- gZ[, t] * X[t]
    
    # add individual fixed effect alpha_i
    Y[, t] <- gx_t + rho_y * Y_prev + alpha + err[, t]
    Y_prev <- Y[, t]
  }
  
  # --- Keep post-burn-in sample of length T ---
  Y_obs    <- Y[, keep_idx, drop = FALSE]
  Z_obs    <- Z[, keep_idx, drop = FALSE]
  gZ_obs   <- gZ[, keep_idx, drop = FALSE]
  eps_obs  <- eps[, keep_idx, drop = FALSE]
  X_obs    <- X[keep_idx]
  u_obs    <- u_raw[, keep_idx, drop = FALSE]
  e_obs    <- e_scaled[, keep_idx, drop = FALSE]
  err_obs  <- err[, keep_idx, drop = FALSE]
  
  # Convenient lags over kept window
  Y_lag_obs <- Y[, keep_idx - 1, drop = FALSE]
  Z_lag_obs <- Z[, keep_idx - 1, drop = FALSE]
  
  # Leads
  Z_leads <- list()
  for (h in seq_len(H)) {
    Z_leads[[paste0("Z_lead", h)]] <- Z[, keep_idx + h, drop = FALSE]
  }
  if (H > 0) {
    X_leads <- sapply(seq_len(H), function(h) X[keep_idx + h])
    colnames(X_leads) <- paste0("X_lead", seq_len(H))
    rownames(X_leads) <- paste0("t", seq_len(T))
  } else {
    X_leads <- matrix(numeric(0), nrow = T, ncol = 0)
  }
  
  # ---------- Long panel data.frame ----------
  make_panel_df <- function() {
    id   <- rep(seq_len(N), each = T)
    time <- rep(seq_len(T), times = N)
    as_rowvec <- function(M) as.vector(t(M))
    
    panel_df <- data.frame(
      id       = id,
      time     = time,
      Y        = as_rowvec(Y_obs),
      Z        = as_rowvec(Z_obs),
      X        = rep(X_obs,      times = N),   # same X_t across i
      X_sq     = rep(X_obs^2,    times = N),   # still provided (convenience)
      Y_lag    = as_rowvec(Y_lag_obs),
      Z_lag    = as_rowvec(Z_lag_obs),
      gZ       = as_rowvec(gZ_obs),
      gX       = as_rowvec(gZ_obs) * rep(X_obs, times = N),
      epsilon  = as_rowvec(eps_obs),
      alpha    = rep(alpha, each = T),
      sigma    = rep(sigma,  each = T),
      sigma2   = rep(sigma2, each = T),
      u_raw    = as_rowvec(u_obs),
      e_scaled = as_rowvec(e_obs),
      err      = as_rowvec(err_obs)
    )
    
    if (include_leads_in_panel && H > 0) {
      for (h in seq_len(H)) {
        panel_df[[paste0("Z_lead", h)]] <- as_rowvec(Z_leads[[h]])
        panel_df[[paste0("X_lead", h)]] <- rep(X[keep_idx + h], times = N)
      }
    }
    
    panel_df$id   <- as.integer(panel_df$id)
    panel_df$time <- as.integer(panel_df$time)
    panel_df
  }
  
  panel_df <- make_panel_df()
  
  # Optional: pdata.frame
  pdata <- NULL
  if (make_pdata && requireNamespace("plm", quietly = TRUE)) {
    pdata <- plm::pdata.frame(panel_df, index = c("id", "time"), drop.index = TRUE)
  }
  
  # ---------- Wide format labels ----------
  make_dimnames <- function(M) {
    colnames(M) <- paste0("t", seq_len(ncol(M)))
    rownames(M) <- paste0("i", seq_len(nrow(M)))
    M
  }
  Y_obs     <- make_dimnames(Y_obs)
  Z_obs     <- make_dimnames(Z_obs)
  Y_lag_obs <- make_dimnames(Y_lag_obs)
  Z_lag_obs <- make_dimnames(Z_lag_obs)
  gZ_obs    <- make_dimnames(gZ_obs)
  eps_obs   <- make_dimnames(eps_obs)
  u_obs     <- make_dimnames(u_obs)
  e_obs     <- make_dimnames(e_obs)
  err_obs   <- make_dimnames(err_obs)
  
  if (H > 0) {
    for (h in seq_len(H)) {
      Z_leads[[h]] <- make_dimnames(Z_leads[[h]])
    }
  }
  
  # ---------- Return ----------
  out_list <- list(
    panel_df = panel_df,
    pdata    = pdata,
    
    Y        = Y_obs,
    Z        = Z_obs,
    X        = X_obs,
    X_sq_t   = X_obs^2,
    Y_lag    = Y_lag_obs,
    Z_lag    = Z_lag_obs,
    g_of_Z   = gZ_obs,
    epsilon  = eps_obs,
    u_raw    = u_obs,
    e_scaled = e_obs,
    error    = err_obs,
    alpha    = alpha,
    sigma        = sigma,
    sigma2       = sigma2,
    Z_leads  = Z_leads,
    X_leads  = X_leads,
    params       = list(
      g_spec     = g_spec,
      rho_y      = rho_y,
      rho_xi     = rho_xi,
      theta      = theta,
      burnin     = burnin,
      var_eps    = var_eps,
      var_eta    = var_eta,
      sigma_mu2  = sigma_mu2, 
      alpha_mode = alpha_mode,
      var_alpha  = var_alpha,
      sigma_mode = sigma_mode,
      H          = H
    )
  )
  
  if (out == "panel") {
    out_list[c("panel_df", "pdata", "params")]
  } else if (out == "wide") {
    out_list[c("Y", "Z", "X", "Y_lag", "Z_lag",
               "g_of_Z", "epsilon", "u_raw", "e_scaled", "error",
               "alpha", "sigma", "sigma2", "Z_leads", "X_leads", "params")]
  } else {
    out_list
  }
}
