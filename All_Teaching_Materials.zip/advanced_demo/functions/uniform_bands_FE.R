# Required libraries
# install.packages("mvtnorm")
# install.packages("glmnet")
library(mvtnorm)
library(splines)
library(glmnet) # for LASSO option

# Gaussian Approximation Bootstrap for Uniform Confidence Bands
#
# Args:
#   data      : data.frame (long format) with columns id, time, Y, X, Z, optional W_vars
#   id_var    : name of the unit identifier column (default "id")
#   time_var  : name of the time identifier column (default "time")
#   Y_var     : name of the outcome variable column
#   X_var     : name of the scalar regressor column
#   Z_var     : name of the index variable for basis functions
#   W_vars    : optional character vector of control column names
#   basis     : "spline", "fourier", "polynomial", or "custom" (default "spline")
#   J         : number of basis functions (ignored unless J_method = "manual")
#   J_method  : "manual", "pcv", "cv", or "lasso" (default "pcv") for choosing J;
#               with the default pcv_metric = "aic" this is the paper's AIC rule
#               With "lasso", only the X*phi(Z) sieve coefficients b_h are
#               penalized; coefficients gamma_h on W_vars are unpenalized.
#   phi_fun   : custom basis function z -> vector of length J (required only if basis == "custom" AND J_method == "manual")
#   H         : maximum forecast horizon (default 0)
#   horizons  : which forecast horizon to run (default 0:H) (e.g. c(1,2,4))
#   Z_grid    : optional evaluation grid; defaults to 100 points over Z's range
#   M         : number of bootstrap draws (default 2000)
#   alpha     : significance level (default 0.05)
#   inference : "uniform" (default) or "pointwise"
#   pcv_metric: "gcv", "rss", "aic" (default), or "bic". gcv guards against the "always-pick-largest-J" issue that "rss" has
#   fe        : TRUE for the within demeaned estimator for unit FE, otherwise FALSE
#   studentized: TRUE (default) uses the studentized supremum for uniform bands;
#                FALSE uses the non-studentized absolute supremum. This option
#                has no effect when inference = "pointwise".
#
# Returns:
#   A list of length H+1; each element is a list with elements for horizon h:
#     J_selected: J selected
#     basis_spec: objects needed to evaluate the selected basis at new Z values
#     b_hat     : estimated sieve coefficients
#     V_hat     : estimated covariance matrix of b_hat
#     se_hat    : estimated standard error on Z_grid
#     crit_val  : critical value for the selected inference type
#     alpha     : significance level used for inference
#     inference : inference type used
#     studentized: whether the uniform-band bootstrap was studentized
#     Z_grid    : evaluation grid
#     g_hat     : point estimates of g(z) on Z_grid
#     lower     : lower confidence interval/band on Z_grid
#     upper     : upper confidence interval/band on Z_grid

gauss_bootstrap_ucb <- function(
    data,
    id_var     = "id",
    time_var   = "time",
    Y_var,
    X_var,
    Z_var,
    W_vars     = NULL,
    basis      = "spline", 
    J          = NULL,
    J_method   = "pcv",    
    phi_fun    = NULL, 
    H          = 0,
    horizons   = NULL,
    Z_grid     = NULL,
    M          = 2000,
    alpha      = 0.05,
    inference  = "uniform",
    pcv_metric  = "aic",
    fe          = FALSE,
    studentized = TRUE
) {
  #----------------------- prep -----------------------
  data <- data[order(data[[time_var]], data[[id_var]]), ]
  Y    <- data[[Y_var]]
  X    <- data[[X_var]]
  Z    <- data[[Z_var]]
  if (!is.null(W_vars)) {
    W <- as.matrix(data[, W_vars, drop = FALSE])
    Q <- ncol(W)
  } else {
    W <- matrix(nrow = nrow(data), ncol = 0)
    Q <- 0
  }
  N <- length(unique(data[[id_var]]))
  T <- length(unique(data[[time_var]]))
  h_vec     <- if (is.null(horizons)) 0:H else sort(unique(as.integer(horizons)))
  J_method  <- match.arg(J_method, c("manual", "pcv", "cv", "lasso"))
  basis     <- match.arg(basis, c("spline", "fourier", "polynomial", "custom"))
  inference <- match.arg(inference, c("uniform", "pointwise"))
  if (!is.logical(studentized) || length(studentized) != 1L || is.na(studentized)) {
    stop("studentized must be a single non-missing logical value (TRUE or FALSE).")
  }
  
  # FE (demeaned / within) option
  fe <- isTRUE(fe)
  demean_vec <- function(v, id) {
    v - ave(v, id, FUN = function(x) mean(x, na.rm = TRUE))
  }
  demean_mat <- function(M, id) {
    if (is.null(M) || length(M) == 0) return(M)
    out <- M
    for (j in seq_len(ncol(out))) out[, j] <- demean_vec(out[, j], id)
    out
  }
  
  # helper: build fourier basis (Ji even) anchored to range(range_z)
  make_fourier <- function(range_z, Ji) {
    Ji <- as.integer(Ji)
    if (Ji %% 2 != 0) Ji <- Ji + 1  # enforce even
    Ji <- max(2L, Ji)
    zmin <- range_z[1]
    zmax <- range_z[2]
    K <- Ji / 2
    function(z) {
      u <- (z - zmin) / (zmax - zmin)
      as.vector(unlist(lapply(1:K, function(k) c(sin(2*pi*k*u), cos(2*pi*k*u)))))
    }
  }
  
  # helper: build polynomial basis (Ji terms, degree = Ji-1)
  make_poly <- function(range_z, Ji) {
    zmin <- range_z[1]
    zmax <- range_z[2]
    function(z) {
      u <- (z - zmin) / (zmax - zmin)
      sapply(0:(Ji-1), function(j) u^j)
    }
  }
  
  # helper: build stable spline basis + predictor (clamps to padded boundary knots)
  make_spline_phi <- function(Z_fit, df_eff, degree = 3, intercept = TRUE, boundary_knots = NULL) {
    bnd <- if (is.null(boundary_knots)) range(Z_fit, na.rm = TRUE) else boundary_knots
    eps <- 1e-10 * diff(bnd)
    if (!is.finite(eps) || eps <= 0) eps <- 1e-8
    bnd <- c(bnd[1] - eps, bnd[2] + eps)
    
    bs_obj <- bs(Z_fit, df = df_eff, degree = degree, intercept = intercept, Boundary.knots = bnd)
    
    phi_fun <- function(z) {
      z2 <- pmin(pmax(z, bnd[1]), bnd[2])
      as.vector(predict(bs_obj, z2))
    }
    
    list(bs_obj = bs_obj, phi_fun = phi_fun, bnd = bnd)
  }
  
  # helper: safe solve with tiny ridge
  safe_solve <- function(A, b = NULL, ridge = 1e-8) {
    p <- ncol(A)
    A2 <- A + ridge * diag(p)
    if (is.null(b)) solve(A2) else solve(A2, b)
  }
  
  # helper: Gaussian draws even if V_hat is nearly singular
  rmvnorm_safe <- function(n, sigma) {
    ok <- TRUE
    out <- try(rmvnorm(n, sigma = sigma), silent = TRUE)
    if (inherits(out, "try-error")) ok <- FALSE
    if (!ok) {
      # eigen fix to nearest PSD (clip negative eigs)
      ee <- eigen((sigma + t(sigma))/2, symmetric = TRUE)
      vals <- pmax(ee$values, 1e-12)
      sigma_psd <- ee$vectors %*% diag(vals) %*% t(ee$vectors)
      out <- rmvnorm(n, sigma = sigma_psd)
    }
    out
  }
  
  #----------------------- main loop -----------------------
  results        <- vector("list", length(h_vec))
  names(results) <- paste0("h=", h_vec)
  
  for (ii in seq_along(h_vec)) {
    h <- h_vec[ii]
    
    # indices for predictors and responses at horizon h
    valid <- which(data[[time_var]] <= T - h)
    resp  <- valid + h * N
    
    Y_h <- Y[resp]
    X_h <- X[valid]
    Z_h <- Z[valid]
    W_h <- if (Q > 0) W[valid, , drop = FALSE] else NULL
    
    # drop rows with any NA across used columns (robust to missing)
    keep <- is.finite(Y_h) & is.finite(X_h) & is.finite(Z_h)
    if (Q > 0) keep <- keep & apply(is.finite(W_h), 1, all)
    Y_h <- Y_h[keep]; X_h <- X_h[keep]; Z_h <- Z_h[keep]
    if (Q > 0) W_h <- W_h[keep, , drop = FALSE]
    
    # id aligned with the post-NA-drop sample at horizon h (needed for FE demeaning)
    id_h <- data[[id_var]][valid][keep]
    
    # recompute sizes at horizon h
    T_h  <- T - h
    n_h_full <- length(Y_h)                     # could be < N*T_h after NA drop
    # Build time-block index for CV/HAC (map surviving rows to their time block)
    # Start from the canonical block labeling before NA drop
    block_idx_full <- match(data[[time_var]][valid],
                            sort(unique(data[[time_var]][data[[time_var]] <= T - h])))
    block_idx_h <- block_idx_full[keep]
    
    
    #-------------------- choose J_h (per-h) --------------------
    if (J_method == "manual") {
      if (is.null(J)) stop("Provide J when J_method = 'manual'.")
      J_h <- as.integer(J)
      # define phi_fun_h from manual inputs/basis
      if (basis == "spline") {
        df_eff <- max(1L, min(J_h, length(unique(Z_h)) - 1L))
        sp_h <- make_spline_phi(Z_h, df_eff = df_eff, degree = 3, intercept = TRUE)
        bs_obj_h  <- sp_h$bs_obj
        phi_fun_h <- sp_h$phi_fun
        J_h <- ncol(predict(bs_obj_h, pmin(pmax(Z_h, sp_h$bnd[1]), sp_h$bnd[2])))  # in case df reduced
      } else if (basis == "fourier") {
        # enforce even and feasible
        J_max_eff_h <- max(2L, min(J_h, 2L * floor((length(unique(Z_h)) - 1L)/2L)))
        phi_fun_h <- make_fourier(range(Z_h), J_max_eff_h)
        J_h <- J_max_eff_h
      } else if (basis == "polynomial") {
        phi_fun_h <- make_poly(range(Z_h), J_h)
      } else if (basis == "custom") {
        if (is.null(phi_fun)) stop("Provide phi_fun when basis == 'custom' and J_method == 'manual'.")
        phi_fun_h <- phi_fun
        # assume user-provided function returns length J_h
      } else stop("Unknown basis type.")
    } 
    else if (J_method == "pcv") {
      # Pseudo-CV (in-sample): choose J by minimizing an in-sample criterion.
      # Default uses GCV (Generalized Cross-Validation), an in-sample approximation to LOOCV.
      pcv_metric <- match.arg(pcv_metric, c("gcv","rss","aic","bic"))
      
      J_max_base <- min(20L, floor(sqrt(max(n_h_full, 1))))
      if (basis == "spline") {
        J_max_eff_h <- max(1L, min(J_max_base, length(unique(Z_h)) - 1L))
        J_cand <- unique(pmax(4L, seq(4L, max(4L, J_max_eff_h), by = 1L)))
      }
      else if (basis == "fourier") {
        J_max_eff_h <- 2L * floor(min(J_max_base, length(unique(Z_h)) - 1L) / 2L)
        J_cand <- unique(pmax(2L, seq(2L, max(2L, J_max_eff_h), by = 2L)))
      }
      else { # basis == "polynomial"
        J_max_eff_h <- max(2L, min(J_max_base, length(unique(Z_h))))
        J_cand <- unique(pmax(2L, seq(2L, max(2L, J_max_eff_h), by = 1L)))
      }
      if (!length(J_cand)) J_cand <- if (basis == "spline") 4L else if (basis == "fourier") 2L else 2L
      
      crit <- sapply(J_cand, function(Ji) {
        # build basis on FULL Z_h for in-sample criterion
        if (basis == "spline") {
          df_eff <- max(4L, min(Ji, length(unique(Z_h)) - 1L))
          sp_tmp <- make_spline_phi(Z_h, df_eff = df_eff, degree = 3, intercept = TRUE)
          Phi <- predict(sp_tmp$bs_obj, pmin(pmax(Z_h, sp_tmp$bnd[1]), sp_tmp$bnd[2]))
        } 
        else if (basis == "fourier") {
          Ji_eff <- as.integer(Ji); if (Ji_eff %% 2 != 0) Ji_eff <- Ji_eff + 1L
          Ji_eff <- max(2L, Ji_eff)
          phi_tmp <- make_fourier(range(Z_h), Ji_eff)
          Phi <- t(sapply(Z_h, phi_tmp))
        }
        else { # basis == "polynomial"
          phi_tmp <- make_poly(range(Z_h), Ji)
          Phi <- t(sapply(Z_h, phi_tmp))
        }
        D <- if (Q > 0) cbind(X_h * Phi, W_h) else X_h * Phi
        
        if (fe) {
          D_use <- demean_mat(D, id_h)
          Y_use <- demean_vec(Y_h, id_h)
        } else {
          D_use <- D
          Y_use <- Y_h
        }
        
        n_i <- nrow(D_use)
        A_i <- crossprod(D_use) / n_i
        B_i <- crossprod(D_use, Y_use) / n_i
        th_i <- safe_solve(A_i, B_i, ridge = 1e-8)
        res  <- as.vector(Y_use - D_use %*% th_i)
        RSS  <- sum(res^2)
        p_i  <- tryCatch(qr(D_use)$rank, error = function(e) ncol(D_use))
        if (pcv_metric == "rss") return(RSS)
        if (pcv_metric == "aic") return(n_i * log(RSS / max(1, n_i)) + 2 * p_i)
        if (pcv_metric == "bic") return(n_i * log(RSS / max(1, n_i)) + log(n_i) * p_i)
        # GCV
        den <- 1 - p_i / n_i
        den <- max(1e-6, den)
        RSS / (n_i * den^2)
      })
      
      J_h <- J_cand[which.min(crit)]
      
      # define phi_fun_h on FULL Z_h (post-selection)
      if (basis == "spline") {
        df_eff <- max(4L, min(J_h, length(unique(Z_h)) - 1L))
        sp_h <- make_spline_phi(Z_h, df_eff = df_eff, degree = 3, intercept = TRUE)
        bs_obj_h  <- sp_h$bs_obj
        phi_fun_h <- sp_h$phi_fun
        J_h <- ncol(predict(bs_obj_h, pmin(pmax(Z_h, sp_h$bnd[1]), sp_h$bnd[2])))
      }
      else if (basis == "fourier") {
        if (J_h %% 2 != 0) J_h <- J_h + 1L
        J_h <- max(2L, J_h)
        phi_fun_h <- make_fourier(range(Z_h), J_h)
      }
      else { # basis == "polynomial"
        phi_fun_h <- make_poly(range(Z_h), J_h)
      }
    } 
    else if (J_method == "cv") {
      # Time-block K-fold CV (avoid leakage along time). Use K = min(5, T_h)
      K <- max(2L, min(5L, T_h))
      # split the T_h blocks into K folds as evenly as possible
      folds <- split(1:T_h, cut(seq_len(T_h), breaks = K, labels = FALSE))
      
      # candidate J's bounded by data richness at horizon h
      J_max_base <- min(20L, floor(sqrt(max(n_h_full, 1))))
      if (basis == "spline") {
        J_max_eff_h <- max(4L, min(J_max_base, length(unique(Z_h)) - 1L))
        J_cand <- unique(pmax(4L, seq(4L, max(4L, J_max_eff_h), by = 1L)))
      }
      else if (basis == "fourier") {
        J_max_eff_h <- 2L * floor(min(J_max_base, length(unique(Z_h)) - 1L) / 2L)
        J_cand <- unique(pmax(2L, seq(2L, max(2L, J_max_eff_h), by = 2L)))
      }
      else { # basis == polynomial
        J_max_eff_h <- max(2L, min(J_max_base, length(unique(Z_h))))
        J_cand <- unique(pmax(2L, seq(2L, max(2L, J_max_eff_h), by = 1L)))
      }
      if (!length(J_cand)) J_cand <- if (basis == "spline") 4L else if (basis == "fourier") 2L else 2L
      
      cv_err <- sapply(J_cand, function(Ji) {
        sse <- 0
        for (kk in seq_along(folds)) {
          test_blocks <- folds[[kk]]
          test_idx <- which(block_idx_h %in% test_blocks)
          train_idx <- setdiff(seq_len(n_h_full), test_idx)
          
          Z_tr <- Z_h[train_idx]; X_tr <- X_h[train_idx]; Y_tr <- Y_h[train_idx]
          Z_te <- Z_h[test_idx];  X_te <- X_h[test_idx];  Y_te <- Y_h[test_idx]
          if (Q > 0) {
            W_tr <- W_h[train_idx, , drop = FALSE]
            W_te <- W_h[test_idx,  , drop = FALSE]
          } 
          else {
            W_tr <- NULL; W_te <- NULL
          }
          
          # build basis anchored on TRAIN set only
          if (basis == "spline") {
            df_eff <- max(4L, min(Ji, length(unique(Z_tr)) - 1L))
            # Use full-sample support at this horizon to avoid boundary warnings in folds
            sp_fold <- make_spline_phi(
              Z_tr,
              df_eff = df_eff,
              degree = 3,
              intercept = TRUE,
              boundary_knots = range(Z_h, na.rm = TRUE)
            )
            Phi_tr <- predict(sp_fold$bs_obj, pmin(pmax(Z_tr, sp_fold$bnd[1]), sp_fold$bnd[2]))
            Phi_te <- predict(sp_fold$bs_obj, pmin(pmax(Z_te, sp_fold$bnd[1]), sp_fold$bnd[2]))
            Ji_eff <- ncol(Phi_tr)
          } 
          else if (basis == "fourier") {
            Ji_eff <- as.integer(Ji)
            if (Ji_eff %% 2 != 0) Ji_eff <- Ji_eff + 1L
            Ji_eff <- max(2L, Ji_eff)
            phi_tmp <- make_fourier(range(Z_tr), Ji_eff)
            Phi_tr <- t(sapply(Z_tr, phi_tmp))
            Phi_te <- t(sapply(Z_te, phi_tmp))
            Ji_eff <- ncol(Phi_tr)
          }
          else { # basis == polynomial
            phi_tmp <- make_poly(range(Z_tr), Ji)
            Phi_tr <- t(sapply(Z_tr, phi_tmp))
            Phi_te <- t(sapply(Z_te, phi_tmp))
            Ji_eff <- ncol(Phi_tr)
          }
          
          D_tr <- if (Q > 0) cbind(X_tr * Phi_tr, W_tr) else X_tr * Phi_tr
          D_te <- if (Q > 0) cbind(X_te * Phi_te, W_te) else X_te * Phi_te
          
          if (fe) {
            id_tr <- id_h[train_idx]
            id_te <- id_h[test_idx]
            D_tr_use <- demean_mat(D_tr, id_tr)
            Y_tr_use <- demean_vec(Y_tr, id_tr)
            D_te_use <- demean_mat(D_te, id_te)
            Y_te_use <- demean_vec(Y_te, id_te)
          } else {
            D_tr_use <- D_tr
            Y_tr_use <- Y_tr
            D_te_use <- D_te
            Y_te_use <- Y_te
          }
          
          A_tr <- crossprod(D_tr_use) / max(1, nrow(D_tr_use))
          B_tr <- crossprod(D_tr_use, Y_tr_use) / max(1, nrow(D_tr_use))
          th_tr <- safe_solve(A_tr, B_tr, ridge = 1e-8)
          resid <- Y_te_use - as.vector(D_te_use %*% th_tr)
          sse <- sse + sum(resid^2)
        }
        sse
      })
      
      J_h <- J_cand[which.min(cv_err)]
      
      # define phi_fun_h on FULL Z_h (post-selection)
      if (basis == "spline") {
        df_eff <- max(4L, min(J_h, length(unique(Z_h)) - 1L))
        sp_h <- make_spline_phi(Z_h, df_eff = df_eff, degree = 3, intercept = TRUE)
        bs_obj_h  <- sp_h$bs_obj
        phi_fun_h <- sp_h$phi_fun
        J_h <- ncol(predict(bs_obj_h, pmin(pmax(Z_h, sp_h$bnd[1]), sp_h$bnd[2])))
      } 
      else if (basis == "fourier") {
        if (J_h %% 2 != 0) J_h <- J_h + 1L
        J_h <- max(2L, J_h)
        phi_fun_h <- make_fourier(range(Z_h), J_h)
      }
      else { # basis == polynomial
        phi_fun_h <- make_poly(range(Z_h), J_h)
      }
    } 
    else if (J_method == "lasso") {
      # Build the maximal J_lasso = 50 dictionary (or the largest feasible
      # dictionary when the empirical support contains fewer distinct values).
      J_lasso <- 50L
      if (basis == "spline") {
        J_max_eff_h <- max(4L, min(J_lasso, length(unique(Z_h)) - 1L))
        sp_big <- make_spline_phi(Z_h, df_eff = J_max_eff_h, degree = 3, intercept = TRUE)
        Phi_big <- predict(sp_big$bs_obj, pmin(pmax(Z_h, sp_big$bnd[1]), sp_big$bnd[2]))
      } 
      else if (basis == "fourier") {
        J_max_base <- J_lasso
        J_max_eff_h <- 2L * floor(min(J_max_base, length(unique(Z_h)) - 1L) / 2L)
        J_max_eff_h <- max(2L, J_max_eff_h)
        phi_big <- make_fourier(range(Z_h), J_max_eff_h)
        Phi_big <- t(sapply(Z_h, phi_big))
      }
      else if (basis == "polynomial") {
        J_max_eff_h <- max(2L, min(J_lasso, length(unique(Z_h))))
        phi_big <- make_poly(range(Z_h), J_max_eff_h)
        Phi_big <- t(sapply(Z_h, phi_big))
      }
      else {
        stop("LASSO selection currently supports 'spline', 'fourier', or 'polynomial' basis.")
      }
      
      D_full <- if (Q > 0) cbind(X_h * Phi_big, W_h) else X_h * Phi_big
      # Implement min RSS + lambda * ||b_h||_1: penalize the sieve block b_h,
      # but leave gamma_h on the lagged outcome and any other W_vars controls
      # unpenalized. With Q = 0 this reduces to ordinary LASSO on b_h.
      penalty_factor_lasso <- c(rep(1, ncol(Phi_big)), rep(0, Q))
      # glmnet drops rows with NA internally, but we've already removed NAs
      if (fe) {
        D_full <- demean_mat(D_full, id_h)
        Y_full <- demean_vec(Y_h, id_h)
      } else {
        Y_full <- Y_h
      }
      cvfit <- glmnet::cv.glmnet(
        D_full,
        Y_full,
        alpha = 1,
        intercept = FALSE,
        penalty.factor = penalty_factor_lasso
      )
      cf    <- as.vector(coef(cvfit, s = "lambda.min"))[-1]  # drop intercept
      # first J_max_eff_h entries correspond to X*Phi columns
      J_h <- sum(abs(cf[seq_len(ncol(Phi_big))]) > 0)
      if (basis == "spline") {
        J_h <- max(4L, min(J_h, ncol(Phi_big)))
      }
      else if (basis == "fourier") {
        # force even and >=2 for fourier
        if (J_h %% 2 != 0) J_h <- J_h + 1L
        J_h <- max(2L, min(J_h, ncol(Phi_big)))
      }
      else { # basis == polynomial
        J_h <- max(2L, min(J_h, ncol(Phi_big)))
      }
      
      # define phi_fun_h from FULL data with J_h
      if (basis == "spline") {
        df_eff <- max(4L, min(J_h, length(unique(Z_h)) - 1L))
        sp_h <- make_spline_phi(Z_h, df_eff = df_eff, degree = 3, intercept = TRUE)
        bs_obj_h  <- sp_h$bs_obj
        phi_fun_h <- sp_h$phi_fun
        J_h <- ncol(predict(bs_obj_h, pmin(pmax(Z_h, sp_h$bnd[1]), sp_h$bnd[2])))
      } 
      else if (basis == "fourier") {
        phi_fun_h <- make_fourier(range(Z_h), J_h)
      }
      else { # basis == "polynomial"
        phi_fun_h <- make_poly(range(Z_h), J_h)
      }
    }
    
    #-------------------- evaluation grid (per-h if not supplied) ------------
    Z_grid_h <- if (is.null(Z_grid)) seq(min(Z_h), max(Z_h), length.out = 100) else Z_grid
    Phi_grid_h <- t(sapply(Z_grid_h, phi_fun_h))  # G x J_h

    basis_spec_h <- list(
      type       = basis,
      J_selected = J_h,
      range_z    = range(Z_h, na.rm = TRUE)
    )
    if (basis == "spline") {
      basis_spec_h$bs_obj <- bs_obj_h
      basis_spec_h$bnd    <- sp_h$bnd
    } else if (basis == "custom") {
      basis_spec_h$phi_fun <- phi_fun_h
    }
    
    #-------------------- estimation at horizon h ----------------------------
    Phi_h <- t(sapply(Z_h, phi_fun_h))            # n_h x J_h
    XPhi  <- X_h * Phi_h                           # n_h x J_h
    
    if (fe) {
      XPhi_use <- demean_mat(XPhi, id_h)
      Y_use    <- demean_vec(Y_h, id_h)
      if (Q > 0) {
        W_use <- demean_mat(W_h, id_h)
      } else {
        W_use <- NULL
      }
    } else {
      XPhi_use <- XPhi
      Y_use    <- Y_h
      W_use    <- W_h
    }
    
    D_h   <- if (Q > 0) cbind(XPhi_use, W_use) else XPhi_use
    
    n_h <- nrow(D_h)
    A   <- crossprod(D_h) / n_h
    B   <- crossprod(D_h, Y_use) / n_h
    th  <- safe_solve(A, B, ridge = 1e-8)
    
    b_hat <- th[1:J_h]
    g_hat <- as.vector(Phi_grid_h %*% b_hat)
    
    gamma_hat <- NULL
    if (Q > 0) {
      gamma_hat <- th[(J_h + 1):(J_h + Q)]
      if (!is.null(W_vars) && length(W_vars) == Q) names(gamma_hat) <- W_vars
    }
    
    # residuals
    v <- as.vector(Y_use - D_h %*% th)
    
    # partial-out blocks for sandwich
    A11 <- A[1:J_h, 1:J_h, drop = FALSE]
    if (Q > 0) {
      A12 <- A[1:J_h, (J_h+1):(J_h+Q), drop = FALSE]
      A22 <- A[(J_h+1):(J_h+Q), (J_h+1):(J_h+Q), drop = FALSE]
      A22i <- safe_solve(A22, ridge = 1e-8)
      tildeA11 <- A11 - A12 %*% A22i %*% t(A12)
    } else {
      tildeA11 <- A11
    }
    
    # HAC: time-block scores (T_h blocks × J_h)
    S_mat <- matrix(0, nrow = T_h, ncol = J_h)
    for (t in seq_len(T_h)) {
      idx <- which(block_idx_h == t)
      if (!length(idx)) next
      # J_h x (#idx): already contains X_h * phi(Z_h)
      M_phi <- t(XPhi_use[idx, , drop = FALSE])
      if (Q > 0) {
        M_w <- A12 %*% A22i %*% t(W_use[idx, , drop = FALSE])  # J_h x (#idx)
      } else {
        M_w <- matrix(0, nrow = J_h, ncol = length(idx))
      }
      S_mat[t, ] <- as.vector((M_phi - M_w) %*% v[idx])
    }
    
    # bandwidth and weights
    L <- floor(4 * (T_h / 100)^(2/9)) # n_h or T_h
    L <- max(0L, min(L, T_h - 1L))
    w <- if (L > 0) (1 - (1:L) / (L + 1)) else numeric(0)
    
    # long-run covariance of scores
    Omega <- crossprod(S_mat, S_mat) / n_h
    if (L > 0) {
      for (k in 1:L) {
        Gk <- crossprod(S_mat[-(1:k), , drop = FALSE],
                        S_mat[1:(nrow(S_mat) - k), , drop = FALSE]) / n_h
        Omega <- Omega + w[k] * (Gk + t(Gk))
      }
    }
    
    V_hat <- (1 / n_h) * safe_solve(tildeA11) %*% Omega %*% safe_solve(tildeA11)
    
    # se_hat = sqrt(diag(Phi_grid_h %*% V_hat %*% t(Phi_grid_h))) implemented efficiently via rowwise products
    se_hat <- sqrt(pmax(0, rowSums((Phi_grid_h %*% V_hat) * Phi_grid_h)))

    if (inference == "uniform") {
      # Gaussian coefficient draws. Compute the bootstrap process over bounded
      # grid chunks below rather than materializing an M x length(Z_grid_h)
      # matrix, which can exceed R's vector-memory limit on a fine grid.
      Zb <- rmvnorm_safe(M, sigma = V_hat)
      if (studentized) {
        # Studentized supremum: max_z |G_h(z) / se_hat(z)|.
        if (any(!is.finite(se_hat))) {
          stop("Cannot construct a studentized uniform band: some grid-point standard errors are non-finite.")
        }
        if (!any(se_hat > 0)) {
          stop("Cannot construct a studentized uniform band: all grid-point standard errors are zero.")
        }
      }

      # Keep each temporary bootstrap-process matrix near 16 MB (before
      # temporary copies made by abs/apply). The running row maxima are exactly
      # the same supremum statistics as those from the full process matrix.
      max_chunk_elements <- 2e6
      grid_chunk_size <- max(1L, as.integer(floor(max_chunk_elements / nrow(Zb))))
      chunk_starts <- seq.int(1L, nrow(Phi_grid_h), by = grid_chunk_size)
      Tvals <- numeric(nrow(Zb))

      for (chunk_start in chunk_starts) {
        chunk_end <- min(chunk_start + grid_chunk_size - 1L, nrow(Phi_grid_h))
        chunk_idx <- chunk_start:chunk_end
        Phi_boot_chunk <- Phi_grid_h[chunk_idx, , drop = FALSE]

        if (studentized) {
          se_chunk <- se_hat[chunk_idx]
          positive_se <- se_chunk > 0

          # Dividing each basis row before matrix multiplication is equivalent
          # to dividing G_h(z) by se_hat(z), while avoiding another M x grid copy.
          if (any(positive_se)) {
            Phi_boot_chunk[positive_se, ] <-
              Phi_boot_chunk[positive_se, , drop = FALSE] / se_chunk[positive_se]
          }
          # A zero estimated variance implies a degenerate bootstrap process at
          # that grid point; its contribution to the standardized supremum is 0.
          if (any(!positive_se)) {
            Phi_boot_chunk[!positive_se, ] <- 0
          }
        }

        G_boot_chunk <- Zb %*% t(Phi_boot_chunk)
        Tvals <- pmax(Tvals, apply(abs(G_boot_chunk), 1, max))
      }

      crit_val <- as.numeric(stats::quantile(Tvals, 1 - alpha))
      band_half_width <- if (studentized) {
        crit_val * se_hat
      } else {
        rep(crit_val, length(se_hat))
      }
      lower <- g_hat - band_half_width
      upper <- g_hat + band_half_width
    } else {
      # Pointwise CI:
      # (g_hat(z) - g(z)) / sigma_hat(z) ~ N(0,1)
      crit_val <- stats::qnorm(1 - alpha / 2)
      lower <- g_hat - crit_val * se_hat
      upper <- g_hat + crit_val * se_hat
    }
    
    results[[ii]] <- list(
      J_selected = J_h,
      basis      = basis,
      basis_spec = basis_spec_h,
      b_hat      = b_hat,
      gamma_hat  = gamma_hat,
      V_hat      = V_hat,
      se_hat     = se_hat,
      crit_val   = crit_val,
      alpha       = alpha,
      inference   = inference,
      studentized = studentized,
      Z_grid      = Z_grid_h,
      g_hat       = g_hat,
      lower       = lower,
      upper       = upper
    )
  }
  
  results
}
