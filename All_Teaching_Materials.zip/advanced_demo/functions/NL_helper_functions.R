
# 1.  Helper function: relabel panel to compact indices id = 1, 2, ..., N; time = 1, 2, ..., T so that the relabelled panel works for our code "uniform_bands.R" ---
relabel_panel <- function(df, id_var = "gvkey", time_var = "dateq") {
  id_sym   <- sym(id_var)
  time_sym <- sym(time_var)
  
  # 1) Ensure deterministic order so time indices are chronological within id
  df <- df %>% arrange(!!id_sym, !!time_sym)
  
  # 2) Build ordered level vectors for ids and time points
  id_levels   <- df %>% distinct(!!id_sym)   %>% arrange(!!id_sym)   %>% pull(!!id_sym)
  time_levels <- df %>% distinct(!!time_sym) %>% arrange(!!time_sym) %>% pull(!!time_sym)
  
  # 3) Map original keys to compact integer indices via match()
  df2 <- df %>% mutate(
    id   = match(!!id_sym,   id_levels),  # 1, 2, ..., N
    time = match(!!time_sym, time_levels) # 1, 2, ..., T
  )
  
  # 4) Lookup tables for translating results back to original labels
  id_lookup   <- tibble(!!id_sym := id_levels, id = seq_along(id_levels))
  time_lookup <- tibble(!!time_sym := time_levels, time = seq_along(time_levels))
  
  list(
    data = df2,
    id_lookup = id_lookup,
    time_lookup = time_lookup,
    N = length(id_levels),
    T = length(time_levels)
  )
}


# Build sector dummy controls, omitting the first sector as the reference category.
make_sector_fe_dummies <- function(sector_values, prefix = "sector_fe") {
  sector_values <- as.character(sector_values)
  sector_values[is.na(sector_values) | sector_values == ""] <- "missing"
  sector_levels <- sort(unique(sector_values))

  if (length(sector_levels) <= 1) {
    return(list(data = tibble::tibble(), vars = character(0)))
  }

  sector_factor <- factor(sector_values, levels = sector_levels)
  sector_dummy_mat <- stats::model.matrix(~ sector_factor)[, -1, drop = FALSE]
  sector_dummy_names <- paste0(
    prefix,
    "_",
    make.names(sector_levels[-1], unique = TRUE)
  )
  colnames(sector_dummy_mat) <- sector_dummy_names

  list(
    data = tibble::as_tibble(sector_dummy_mat),
    vars = sector_dummy_names
  )
}


# Build horizon-specific future interaction controls for X_{t+j} times a polynomial in Z_{t+j-1}.
build_cumulative_lead_controls <- function(df, id_var, time_var, Z_var_list, X_var, max_horizon, poly_degree = 3) {
  if (max_horizon <= 0) {
    return(list(data = df, control_map = list()))
  }
  
  df_out <- df %>%
    arrange(.data[[id_var]], .data[[time_var]])
  
  for (Z_var in Z_var_list) {
    for (j in seq_len(max_horizon)) {
      z_lead_name <- paste0(Z_var, "_lead", j)
      x_lead_name <- paste0(X_var, "_lead", j)
      
      if (!z_lead_name %in% names(df_out)) {
        df_out <- df_out %>%
          group_by(.data[[id_var]]) %>%
          arrange(.data[[time_var]], .by_group = TRUE) %>%
          mutate(!!z_lead_name := lead(.data[[Z_var]], n = j)) %>%
          ungroup()
      }
      
      if (!x_lead_name %in% names(df_out)) {
        df_out <- df_out %>%
          group_by(.data[[id_var]]) %>%
          arrange(.data[[time_var]], .by_group = TRUE) %>%
          mutate(!!x_lead_name := lead(.data[[X_var]], n = j)) %>%
          ungroup()
      }
    }
  }
  
  control_map <- vector("list", length(Z_var_list))
  names(control_map) <- Z_var_list
  
  for (Z_var in Z_var_list) {
    horizon_controls <- vector("list", max_horizon)
    names(horizon_controls) <- as.character(seq_len(max_horizon))
    
    for (h in seq_len(max_horizon)) {
      control_names_h <- character(0)
      
      for (j in seq_len(h)) {
        x_lead_name <- paste0(X_var, "_lead", j)
        z_lead_name <- paste0(Z_var, "_lead", j)
        
        for (power in 0:poly_degree) {
          control_name <- paste0("lead_", Z_var, "_", X_var, "_j", j, "_poly", power)
          
          if (!control_name %in% names(df_out)) {
            if (power == 0) {
              df_out[[control_name]] <- df_out[[x_lead_name]]
            } else {
              df_out[[control_name]] <- (df_out[[z_lead_name]] ^ power) * df_out[[x_lead_name]]
            }
          }
          
          control_names_h <- c(control_names_h, control_name)
        }
      }
      
      horizon_controls[[as.character(h)]] <- control_names_h
    }
    
    control_map[[Z_var]] <- horizon_controls
  }
  
  list(data = df_out, control_map = control_map)
}


validate_required_columns <- function(df, required_cols, context = "estimation") {
  missing_cols <- setdiff(unique(required_cols), names(df))
  
  if (length(missing_cols) > 0) {
    stop(
      paste0(
        "Missing columns in data for ", context, ": ",
        paste(missing_cols, collapse = ", ")
      ),
      call. = FALSE
    )
  }
}

nl_first_non_null <- function(...) {
  values <- list(...)
  for (value in values) {
    if (!is.null(value)) return(value)
  }
  NULL
}

evaluate_sieve_basis <- function(z, fit) {
  if (is.null(fit)) stop("fit must be a gauss_bootstrap_ucb horizon result.", call. = FALSE)
  
  z <- as.numeric(z)
  basis_spec <- nl_first_non_null(fit$basis_spec, fit)
  basis_type <- nl_first_non_null(basis_spec$type, basis_spec$basis, fit$basis)
  J_selected <- nl_first_non_null(basis_spec$J_selected, fit$J_selected)
  
  if (is.null(basis_type)) {
    stop("Cannot evaluate sieve basis because the fit does not store basis information.", call. = FALSE)
  }
  
  if (basis_type == "spline") {
    bs_obj <- nl_first_non_null(basis_spec$bs_obj, fit$bs_obj)
    bnd <- nl_first_non_null(basis_spec$bnd, fit$bnd)
    
    if (is.null(bs_obj) || is.null(bnd)) {
      stop("Spline fits need basis_spec$bs_obj and basis_spec$bnd to evaluate phi(z).", call. = FALSE)
    }
    
    z_clamped <- pmin(pmax(z, bnd[1]), bnd[2])
    Phi <- as.matrix(predict(bs_obj, z_clamped))
  } else if (basis_type == "fourier") {
    range_z <- nl_first_non_null(basis_spec$range_z, fit$range_z)
    if (is.null(range_z) && !is.null(fit$Z_grid)) range_z <- range(fit$Z_grid, na.rm = TRUE)
    if (is.null(J_selected) || is.null(range_z) || !all(is.finite(range_z)) || diff(range_z) == 0) {
      stop("Fourier fits need J_selected and a non-degenerate Z range.", call. = FALSE)
    }
    
    J_selected <- as.integer(J_selected)
    if (J_selected %% 2 != 0) J_selected <- J_selected + 1L
    K <- J_selected / 2
    u <- (z - range_z[1]) / diff(range_z)
    Phi <- do.call(cbind, lapply(seq_len(K), function(k) {
      cbind(sin(2 * pi * k * u), cos(2 * pi * k * u))
    }))
  } else if (basis_type == "polynomial") {
    range_z <- nl_first_non_null(basis_spec$range_z, fit$range_z)
    if (is.null(range_z) && !is.null(fit$Z_grid)) range_z <- range(fit$Z_grid, na.rm = TRUE)
    if (is.null(J_selected) || is.null(range_z) || !all(is.finite(range_z)) || diff(range_z) == 0) {
      stop("Polynomial fits need J_selected and a non-degenerate Z range.", call. = FALSE)
    }
    
    u <- (z - range_z[1]) / diff(range_z)
    Phi <- outer(u, seq_len(as.integer(J_selected)) - 1L, `^`)
  } else if (basis_type == "custom") {
    phi_fun <- nl_first_non_null(basis_spec$phi_fun, fit$phi_fun)
    if (is.null(phi_fun)) {
      stop("Custom fits need a stored phi_fun to evaluate phi(z).", call. = FALSE)
    }
    
    if (is.null(J_selected)) {
      first_phi <- as.numeric(phi_fun(z[1]))
      J_selected <- length(first_phi)
    }
    Phi <- t(vapply(z, function(zz) as.numeric(phi_fun(zz)), numeric(J_selected)))
  } else {
    stop("Unknown basis type: ", basis_type, call. = FALSE)
  }
  
  if (length(z) == 1L && nrow(Phi) != 1L) {
    Phi <- matrix(as.numeric(Phi), nrow = 1L)
  }
  
  if (!is.null(J_selected) && ncol(Phi) != as.integer(J_selected)) {
    stop(
      "Basis evaluation returned ", ncol(Phi), " columns, but J_selected is ",
      as.integer(J_selected), ".",
      call. = FALSE
    )
  }
  
  Phi
}


compute_sieve_contrast <- function(fit, z_a, z_b, alpha = NULL, crit_val = NULL) {
  if (length(z_a) == 1L && length(z_b) > 1L) z_a <- rep(z_a, length(z_b))
  if (length(z_b) == 1L && length(z_a) > 1L) z_b <- rep(z_b, length(z_a))
  if (length(z_a) != length(z_b)) {
    stop("z_a and z_b must have the same length, or one must be scalar.", call. = FALSE)
  }
  
  if (is.null(fit$b_hat) || is.null(fit$V_hat)) {
    stop("fit must contain b_hat and V_hat.", call. = FALSE)
  }
  b_hat <- as.numeric(fit$b_hat)
  V_hat <- as.matrix(fit$V_hat)
  
  Phi_a <- evaluate_sieve_basis(z_a, fit)
  Phi_b <- evaluate_sieve_basis(z_b, fit)
  Phi_diff <- Phi_a - Phi_b
  
  if (ncol(Phi_diff) != length(b_hat) || any(dim(V_hat) != c(length(b_hat), length(b_hat)))) {
    stop("b_hat, V_hat, and the evaluated basis do not have compatible dimensions.", call. = FALSE)
  }
  
  g_hat_a <- as.vector(Phi_a %*% b_hat)
  g_hat_b <- as.vector(Phi_b %*% b_hat)
  diff_hat <- as.vector(Phi_diff %*% b_hat)
  var_hat <- rowSums((Phi_diff %*% V_hat) * Phi_diff)
  se_hat <- sqrt(pmax(0, var_hat))
  
  alpha_use <- nl_first_non_null(alpha, fit$alpha)
  if (is.null(crit_val)) {
    if (is.null(alpha_use)) {
      stop("Provide alpha, or store alpha in the fit, to form a pointwise CI.", call. = FALSE)
    }
    crit_val <- stats::qnorm(1 - alpha_use / 2)
  }
  
  tibble::tibble(
    z_a = as.numeric(z_a),
    z_b = as.numeric(z_b),
    g_hat_a = g_hat_a,
    g_hat_b = g_hat_b,
    diff_hat = diff_hat,
    var_hat = var_hat,
    se_hat = se_hat,
    crit_val = as.numeric(crit_val),
    lower = diff_hat - as.numeric(crit_val) * se_hat,
    upper = diff_hat + as.numeric(crit_val) * se_hat,
    alpha = if (is.null(alpha_use)) NA_real_ else as.numeric(alpha_use)
  )
}


compute_diff_percentile_irfs <- function(ucb_fits, data, percentile_a = 0.95, percentile_b = 0.50,
                                         method = "PCV-GCV", alpha = NULL) {
  if (length(percentile_a) != 1L || length(percentile_b) != 1L) {
    stop("percentile_a and percentile_b must be scalar probabilities.", call. = FALSE)
  }
  if (is.null(ucb_fits) || !length(ucb_fits)) {
    stop("ucb_fits is empty. Save the horizon-level gauss_bootstrap_ucb results first.", call. = FALSE)
  }
  
  rows <- lapply(names(ucb_fits), function(fit_name) {
    fit <- ucb_fits[[fit_name]]
    fit_method <- as.character(nl_first_non_null(fit$method, NA_character_))
    if (!is.null(method) && (is.na(fit_method) || !(fit_method %in% method))) return(NULL)
    
    Z_var <- as.character(nl_first_non_null(fit$Z_var, NA_character_))
    if (is.na(Z_var) || !Z_var %in% names(data)) {
      stop("Cannot compute percentile contrast for fit ", fit_name, ": missing Z_var metadata or data column.", call. = FALSE)
    }
    
    z_a <- as.numeric(stats::quantile(data[[Z_var]], percentile_a, na.rm = TRUE, names = FALSE))
    z_b <- as.numeric(stats::quantile(data[[Z_var]], percentile_b, na.rm = TRUE, names = FALSE))
    alpha_use <- nl_first_non_null(alpha, fit$alpha)
    contrast <- compute_sieve_contrast(fit, z_a, z_b, alpha = alpha_use)
    
    horizon_chr <- as.character(nl_first_non_null(fit$horizon, NA_character_))
    horizon_num <- suppressWarnings(as.integer(sub("^h=", "", horizon_chr)))
    
    dplyr::mutate(
      contrast,
      fit_name = fit_name,
      Z_var = Z_var,
      horizon = horizon_chr,
      horizon_num = horizon_num,
      method = fit_method,
      percentile_a = percentile_a,
      percentile_b = percentile_b,
      contrast_label = paste0(
        round(100 * percentile_a, 2), "th - ",
        round(100 * percentile_b, 2), "th percentile"
      ),
      .before = 1
    )
  })
  
  rows <- Filter(Negate(is.null), rows)
  if (!length(rows)) return(tibble::tibble())
  
  out <- dplyr::bind_rows(rows)
  dplyr::arrange(out, Z_var, method, percentile_a, percentile_b, horizon_num)
}

#2.  Helper function to compute nonlinear LP and its bands
run_ucb_once <- function(df, Z_var, X_var, W_vars_use, 
                         h, Yvarname, J_method = "manual", pcv_metric = NULL, 
                         basis = "spline", J = 6, alpha=0.68, fe=FALSE,
                         inference = "uniform", studentized = TRUE) {
  
  # 1) set horizon-specific dependent variable
  Y_var_h <- paste0("cumF", h, Yvarname)
  
  # 2) clean rows needed for this horizon (since Y changes with h)
  needed_cols_h <- unique(c("id", "time", Y_var_h, Z_var, X_var, W_vars_use))
  validate_required_columns(df, needed_cols_h, context = paste0("run_ucb_once(h=", h, ", Z_var=", Z_var, ", X_var=", X_var, ")"))
  df_clean_h <- df %>% tidyr::drop_na(all_of(intersect(needed_cols_h, names(df))))
  
  # 3) evaluation grid based on used sample
  Z_grid_h <- sort(unique(df_clean_h[[Z_var]]))
  
  # 4) run confidence intervals/bands
  set.seed(123)
  fit <- gauss_bootstrap_ucb(
    data      = df_clean_h,
    id_var    = "id",
    time_var  = "time",
    Y_var     = Y_var_h,
    Z_var     = Z_var,
    X_var     = X_var,
    W_vars    = W_vars_use,
    basis     = basis,
    J         = J,            # gives the dictionary size; used by lasso/pcv to select within
    J_method  = J_method,     # "lasso" or "pcv"
    H         = 0,
    Z_grid    = Z_grid_h,
    alpha     = alpha,
    inference = inference,
    studentized = studentized,
    pcv_metric = pcv_metric, # only used when J_method = "pcv"
    fe = fe
  )
  
  # 5) extract per-h results (supports both nested and flat returns)
  node <- fit[[paste0("h=", 0)]]
  if (is.null(node)) node <- fit
  
  stopifnot(!is.null(node$g_hat), !is.null(node$lower), !is.null(node$upper))
  
  # 6) assemble tidy frame
  method_lab <- switch(
    J_method,
    lasso = "LASSO",
    pcv   = paste0("PCV-", toupper(pcv_metric %||% "GCV")),
    J_method
  )
  
  out <- tibble::tibble(
    Z_var = Z_var,
    horizon = paste0("h=", h),
    method  = method_lab,
    inference = as.character(node$inference %||% inference),
    studentized = as.logical(node$studentized %||% studentized),
    Z       = as.numeric(node$Z_grid),
    g_hat   = as.numeric(node$g_hat),
    lower   = as.numeric(node$lower),
    upper   = as.numeric(node$upper)
  ) %>% arrange(Z)
  
  node$Z_var <- Z_var
  node$horizon <- paste0("h=", h)
  node$method <- method_lab
  node$X_var <- X_var
  node$Y_var <- Y_var_h
  node$W_vars <- W_vars_use
  node$J_method <- J_method
  node$pcv_metric <- pcv_metric
  node$alpha <- alpha
  attr(out, "ucb_details") <- node
  
  out
}


#3. Helper Function to run OW specification

run_OW_regression <- function(df, Z_var, X_var, W_vars_use, h, fixed_effects = "none", CI_param, Yvarname){
  

  
  fixed_effects <- match.arg(fixed_effects, c("none", "firm"))
  Y_var_h <- paste0("cumF", h, Yvarname)
  interac_term_name <- paste(Z_var, "_", X_var, sep="")
  
  # 2) clean rows needed for this horizon (since Y changes with h)
  needed_cols_h <- unique(c("id", "time", Y_var_h, interac_term_name, Z_var, X_var, W_vars_use))
  validate_required_columns(df, needed_cols_h, context = paste0("run_OW_regression(h=", h, ", Z_var=", Z_var, ", X_var=", X_var, ")"))
  df_clean_h <- df %>% tidyr::drop_na(all_of(intersect(needed_cols_h, names(df))))
  
  # 3) evaluation grid based on used sample
  Z_grid_h <- sort(unique(df_clean_h[[Z_var]]))
  
  y <- as.numeric(df_clean_h[[Y_var_h]])
  d <- as.numeric(df_clean_h[[interac_term_name]])
  W <- if (length(W_vars_use) > 0) {
    as.matrix(df_clean_h[, W_vars_use, drop = FALSE])
  } else {
    matrix(nrow = nrow(df_clean_h), ncol = 0)
  }

  demean_vec <- function(v, id) {
    v - ave(v, id, FUN = function(x) mean(x, na.rm = TRUE))
  }

  demean_mat <- function(M, id) {
    if (is.null(M) || ncol(M) == 0) return(M)
    out <- M
    for (j in seq_len(ncol(out))) {
      out[, j] <- demean_vec(out[, j], id)
    }
    out
  }

  partial_out <- function(v, controls) {
    if (is.null(controls) || ncol(controls) == 0) return(as.numeric(v))

    controls <- as.matrix(controls)
    qr_controls <- qr(controls)
    if (qr_controls$rank == 0) return(as.numeric(v))

    controls_rank <- controls[, qr_controls$pivot[seq_len(qr_controls$rank)], drop = FALSE]
    as.numeric(stats::lm.fit(x = controls_rank, y = v)$residuals)
  }

  control_rank <- function(controls) {
    if (is.null(controls) || ncol(controls) == 0) return(0L)
    qr(as.matrix(controls))$rank
  }

  if (fixed_effects == "firm") {
    y <- demean_vec(y, df_clean_h$id)
    d <- demean_vec(d, df_clean_h$id)
    W <- demean_mat(W, df_clean_h$id)
    controls <- W
  } else {
    controls <- cbind(intercept = 1, W)
  }

  # Estimate the OW interaction after partialling out controls. This is robust to
  # sector, time, and sector-time dummy controls, including after firm demeaning.
  y_res <- partial_out(y, controls)
  d_res <- partial_out(d, controls)
  d_ss <- sum(d_res^2)

  if (!is.finite(d_ss) || d_ss <= .Machine$double.eps) {
    stop(
      paste0(
        "Could not estimate the OW interaction coefficient after partialling out controls: ",
        interac_term_name
      ),
      call. = FALSE
    )
  }

  beta <- sum(d_res * y_res) / d_ss
  residuals <- y_res - beta * d_res
  df_resid <- length(y_res) - control_rank(controls) - 1L

  if (df_resid <= 0) {
    stop("Not enough residual degrees of freedom to estimate the OW linear standard error.", call. = FALSE)
  }

  se <- sqrt(sum(residuals^2) / df_resid / d_ss)
  
  
  
  out <- tibble::tibble(
    Z_var = Z_var,
    horizon = paste0("h=", h),
    method  = paste0("OW_FE_", fixed_effects),
    Z       = Z_grid_h
  ) %>% arrange(Z)
  
  out <- out %>% mutate(g_hat = beta*Z, 
                        lower = (beta - CI_param*se)*Z,
                        upper = (beta + CI_param*se)*Z)
  out
  
}





# Helper function to compute nonlinear LP and its bands (from xiyu's FE code)
run_ucb_once_xiyu <- function(df_id_time, Z_var, X_var, W_vars_use, h, Yvarname, fe, J_method = "manual", pcv_metric = NULL, basis = "spline", J = 6, alpha, inference = "uniform", studentized = TRUE) {
  # 1) set horizon-specific dependent variable
  Y_var_h <- paste0("cumF", h, Yvarname)
  
  # 2) clean rows needed for this horizon (since Y changes with h)
  needed_cols_h <- unique(c("id", "time", Y_var_h, Z_var, X_var, W_vars_use))
  validate_required_columns(df_id_time, needed_cols_h, context = paste0("run_ucb_once_xiyu(h=", h, ", Z_var=", Z_var, ", X_var=", X_var, ")"))
  df_clean_h <- df_id_time %>% tidyr::drop_na(all_of(intersect(needed_cols_h, names(df_id_time))))
  
  # 3) evaluation grid based on used sample
  Z_grid_h <- sort(unique(df_clean_h[[Z_var]]))
  
  # 4) run confidence intervals/bands
  set.seed(123)
  fit <- gauss_bootstrap_ucb(
    data          = df_clean_h,
    id_var        = "id",
    time_var      = "time",
    Y_var         = Y_var_h,
    Z_var         = Z_var,
    X_var         = X_var,
    W_vars        = W_vars_use,
    basis         = basis,
    J             = J,            # gives the dictionary size; used by lasso/pcv to select within
    J_method      = J_method,     # "lasso" or "pcv"
    H             = 0,
    Z_grid        = Z_grid_h,
    alpha         = alpha,
    inference     = inference,
    studentized   = studentized,
    pcv_metric    = pcv_metric,   # only used when J_method = "pcv"
    fe            = fe
  )
  
  # 5) extract per-h results (supports both nested and flat returns)
  node <- fit[[paste0("h=", 0)]]
  if (is.null(node)) node <- fit
  
  stopifnot(!is.null(node$g_hat), !is.null(node$lower), !is.null(node$upper))
  
  # 6) assemble tidy frame
  method_lab <- switch(
    J_method,
    lasso = "LASSO",
    pcv   = paste0("PCV-", toupper(pcv_metric %||% "GCV")),
    J_method
  )
  
  out <- tibble::tibble(
    Z_var = Z_var,
    horizon = paste0("h=", h),
    method  = method_lab,
    inference = as.character(node$inference %||% inference),
    studentized = as.logical(node$studentized %||% studentized),
    Z       = as.numeric(node$Z_grid),
    g_hat   = as.numeric(node$g_hat),
    lower   = as.numeric(node$lower),
    upper   = as.numeric(node$upper)
  ) %>% arrange(Z)
  
  node$Z_var <- Z_var
  node$horizon <- paste0("h=", h)
  node$method <- method_lab
  node$X_var <- X_var
  node$Y_var <- Y_var_h
  node$W_vars <- W_vars_use
  node$J_method <- J_method
  node$pcv_metric <- pcv_metric
  node$alpha <- alpha
  attr(out, "ucb_details") <- node
  
  out
}
