# =====================================================================
# course_helpers.R  --  short helpers used in the course
# Estimation and inference are done by gauss_bootstrap_ucb() (paper code).
# These helpers (A) prepare real data, (B) read the fitted output and
# (C) draw pictures.
# =====================================================================

# Horizons stored in a fit list: "h=0", "h=1", ... -> 0, 1, ...
horizons_of <- function(fits) as.integer(sub("h=", "", names(fits)))


# ---- (A) Preparing your own panel -----------------------------------

# A1. Check the layout required by gauss_bootstrap_ucb():
#     one row per (id, time), and time labelled 1, 2, ..., T.
check_panel <- function(dat) {
  n_id   <- length(unique(dat$id))
  n_time <- length(unique(dat$time))
  stopifnot(
    "time must be 1, 2, ..., T"           = all(sort(unique(dat$time)) == 1:n_time),
    "panel must be balanced (one row per id-time)" =
      nrow(unique(dat[c("id", "time")])) == n_id * n_time && nrow(dat) == n_id * n_time
  )
  cat("Balanced panel:", n_id, "units x", n_time, "periods\n")
}


# A2. Turn an unbalanced panel into the balanced layout above.
#     id_var, time_var : your unit and period columns (any type)
#     periods          : optional full list of calendar periods; by default
#                        every period that appears in the data
#     Missing (unit, period) slots become rows of NA, which the estimator
#     drops. The original keys are kept as id_orig and time_orig.
complete_panel <- function(dat, id_var, time_var, periods = NULL) {
  ids <- sort(unique(dat[[id_var]]))
  if (is.null(periods)) periods <- sort(unique(dat[[time_var]]))
  grid <- expand.grid(time_orig = periods, id_orig = ids,
                      KEEP.OUT.ATTRS = FALSE, stringsAsFactors = FALSE)
  names(dat)[names(dat) == id_var]   <- "id_orig"
  names(dat)[names(dat) == time_var] <- "time_orig"
  out <- merge(grid, dat, by = c("id_orig", "time_orig"), all.x = TRUE)
  out$id   <- match(out$id_orig, ids)          # 1, ..., N
  out$time <- match(out$time_orig, periods)    # 1, ..., T
  out <- out[order(out$id, out$time), ]
  rownames(out) <- NULL
  n_added <- nrow(out) - nrow(dat)
  cat("Completed panel:", length(ids), "units x", length(periods), "periods;",
      n_added, "missing slots filled with NA\n")
  out
}


# A3. Lag (k > 0) or lead (k < 0) a variable within each unit.
#     Requires the completed panel from complete_panel().
lag_by_unit <- function(dat, var, k = 1) {
  x <- dat[[var]]
  out <- rep(NA_real_, length(x))
  for (rows in split(seq_along(x), dat$id)) {
    rows <- rows[order(dat$time[rows])]
    n <- length(rows)
    if (k > 0 && n > k)  out[rows[(k + 1):n]] <- x[rows[1:(n - k)]]
    if (k < 0 && n > -k) out[rows[1:(n + k)]] <- x[rows[(1 - k):n]]
    if (k == 0)          out[rows] <- x[rows]
  }
  out
}


# A4. Cumulative outcomes  y_cum<h> = y_{i,t+h} - y_{i,t-1},  h = 0, ..., H.
add_cumulative_outcomes <- function(dat, y, H) {
  base <- lag_by_unit(dat, y, 1)
  for (h in 0:H) {
    dat[[paste0(y, "_cum", h)]] <- lag_by_unit(dat, y, -h) - base
  }
  dat
}


# A5. Run gauss_bootstrap_ucb() once per pre-built outcome  <prefix><h>,
#     each with H = 0, and return the same structure as a normal fit list
#     ("h=0", "h=1", ...). Other arguments are passed on unchanged.
fit_by_horizon <- function(dat, y_prefix, H, ...) {
  fits <- lapply(0:H, function(h) {
    gauss_bootstrap_ucb(data = dat, Y_var = paste0(y_prefix, h), H = 0, ...)[["h=0"]]
  })
  names(fits) <- paste0("h=", 0:H)
  fits
}


# ---- (B) Reading the fitted output ----------------------------------

# B1. The estimated curve g_h(z) and its UNIFORM band at one horizon h.
#     Returns a table with columns z, estimate, lower, upper.
band_at_horizon <- function(fits, h) {
  f <- fits[[paste0("h=", h)]]
  data.frame(z = f$Z_grid, estimate = f$g_hat, lower = f$lower, upper = f$upper)
}


# B2. POINTWISE estimates over horizons at fixed states.
#      z_b = NULL : the response g_h(z_a)
#      z_b given  : the contrast g_h(z_a) - g_h(z_b)
#    Uses the stored coefficients b_hat and their covariance V_hat:
#      estimate = d' b_hat,  se = sqrt(d' V_hat d),  d = phi(z_a) [- phi(z_b)]
pointwise_path <- function(fits, z_a, z_b = NULL, alpha = 0.05) {
  crit <- qnorm(1 - alpha / 2)
  rows <- lapply(fits, function(f) {
    d <- evaluate_sieve_basis(z_a, f)
    if (!is.null(z_b)) d <- d - evaluate_sieve_basis(z_b, f)
    estimate <- drop(d %*% f$b_hat)
    se       <- sqrt(drop(d %*% f$V_hat %*% t(d)))
    data.frame(estimate = estimate, se = se,
               lower = estimate - crit * se, upper = estimate + crit * se)
  })
  cbind(horizon = horizons_of(fits), do.call(rbind, rows), row.names = NULL)
}


# ---- (C) Plots ------------------------------------------------------

# C1. Plot any of the tables above.
#     x = "z" for a state curve, x = "horizon" for a path.
#     If the table has a column 'truth', it is drawn as a dashed orange line.
plot_irf <- function(tab, x = "z", xlab = x, ylab = "Response") {
  p <- ggplot(tab, aes(x = .data[[x]])) +
    geom_ribbon(aes(ymin = lower, ymax = upper), fill = "#C9D8F2") +
    geom_hline(yintercept = 0, colour = "grey60", linetype = 3) +
    geom_line(aes(y = estimate), colour = "#1F3FBF", linewidth = 1)
  if ("truth" %in% names(tab)) {
    p <- p + geom_line(aes(y = truth), colour = "#FF7F00",
                       linetype = 2, linewidth = 1)
  }
  if (x == "horizon") {
    p <- p + geom_point(aes(y = estimate), colour = "#1F3FBF") +
      scale_x_continuous(breaks = tab$horizon)
  }
  p + labs(x = xlab, y = ylab) + theme_minimal(base_size = 14)
}


# C2. Compare several fits in one plot, e.g.
#       plot_compare(list(Sieve = tab_sieve, Linear = tab_linear))
#     Each table needs the columns x, estimate, lower, upper. A 'truth'
#     column in the FIRST table is drawn as a dashed orange line.
plot_compare <- function(tabs, x = "z", xlab = x, ylab = "Response") {
  d <- do.call(rbind, Map(function(tab, name) {
    data.frame(x = tab[[x]], estimate = tab$estimate,
               lower = tab$lower, upper = tab$upper, fit = name)
  }, tabs, names(tabs)))
  d$fit <- factor(d$fit, levels = names(tabs))
  cols <- setNames(c("#1F3FBF", "#B22222", "#2CA02C")[seq_along(tabs)], names(tabs))
  p <- ggplot(d, aes(x = x)) +
    geom_ribbon(aes(ymin = lower, ymax = upper, fill = fit), alpha = 0.2) +
    geom_hline(yintercept = 0, colour = "grey60", linetype = 3) +
    geom_line(aes(y = estimate, colour = fit), linewidth = 1) +
    scale_colour_manual(values = cols) + scale_fill_manual(values = cols)
  if ("truth" %in% names(tabs[[1]])) {
    truth <- data.frame(x = tabs[[1]][[x]], truth = tabs[[1]]$truth)
    p <- p + geom_line(data = truth, aes(x = x, y = truth),
                       colour = "#FF7F00", linetype = 2, linewidth = 1)
  }
  p + labs(x = xlab, y = ylab, colour = NULL, fill = NULL) +
    theme_minimal(base_size = 14)
}
