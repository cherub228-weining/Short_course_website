# =====================================================================
# Demo 1: quadratic state dependence, g(z) = 1 - z^2 (hump-shaped)
# Run section by section from the R_code_demo folder.
# =====================================================================
source("00_setup.R")


# ---- Step 1. Simulate a panel with a known response ------------------
# Y_it = g(Z_i,t-1) X_t + 0.8 Y_i,t-1 + error,  with g(z) = 1 - z^2 (hump-shaped).
# The true causal response is IRF_h(z; delta) = g_h(z) * delta,
# with g_h(z) = 0.8^h * g(z).
H      <- 12                     # longest horizon
true_g <- function(z) 1 - z^2

sim <- simulate_DGP_paranhos(
  N = 80, T = 240, H = H, g_spec = "quadratic",
  theta = 0,                     # no MA error, so Y_lag is a valid control
  alpha_mode = "zero",           # no unit fixed effects
  seed = 19011, make_pdata = FALSE, out = "panel"
)
dat <- sim$panel_df[, c("id", "time", "Y", "X", "Z", "Y_lag")]
# Row (i,t): Y = Y_it, X = X_t, Z = Z_i,t-1, Y_lag = Y_i,t-1
head(dat)                        # X is the same for all units at each time
check_panel(dat)


# ---- Step 2. Estimate g_h(z) for h = 0, ..., 12 -----------------------
# Grid Z_G for the uniform band: the middle 98% of observed states.
z_grid <- seq(quantile(dat$Z, 0.01), quantile(dat$Z, 0.99), length.out = 101)

set.seed(19111)                  # for the Gaussian draws behind the band
fits <- gauss_bootstrap_ucb(
  data = dat, Y_var = "Y", X_var = "X", Z_var = "Z",
  W_vars   = "Y_lag",            # control variables
  basis    = "spline",           # cubic B-splines phi_1(z), ..., phi_J(z)
  J_method = "manual", J = 4,    # fixed sieve dimension
  H        = H,                  # horizons 0, ..., H
  Z_grid   = z_grid,
  inference = "uniform", alpha = 0.05   # B = M = 2000 Gaussian draws
)
names(fits)                      # "h=0" "h=1" ... "h=12"
fits[["h=0"]]$b_hat              # sieve coefficients b_h at h = 0


# ---- Step 3. The state curve at a fixed horizon (uniform band) --------
curve0 <- band_at_horizon(fits, h = 0)
curve0$truth <- true_g(curve0$z)
plot_irf(curve0, x = "z", xlab = "State z", ylab = "g_0(z)")

curve4 <- band_at_horizon(fits, h = 4)
curve4$truth <- 0.8^4 * true_g(curve4$z)
plot_irf(curve4, x = "z", xlab = "State z", ylab = "g_4(z)")


# ---- Step 4. Compare with the standard linear-interaction LP ----------
# basis = "polynomial" with J = 2 gives g_h(z) = alpha_h + beta_h z.
set.seed(19111)
linear <- gauss_bootstrap_ucb(
  data = dat, Y_var = "Y", X_var = "X", Z_var = "Z", W_vars = "Y_lag",
  basis = "polynomial", J_method = "manual", J = 2,
  H = H, Z_grid = z_grid, inference = "uniform", alpha = 0.05
)
compare0 <- list(Sieve  = band_at_horizon(fits,   h = 0),
                 Linear = band_at_horizon(linear, h = 0))
compare0$Sieve$truth <- true_g(compare0$Sieve$z)
plot_compare(compare0, x = "z", xlab = "State z", ylab = "g_0(z)")
# The linear fit is a downward-sloping line: it says the response simply
# falls with z, and misses the hump. Its tight band is precise but wrong.


# ---- Step 5. The response path at a fixed state z = 1 (pointwise) -----
path <- pointwise_path(fits, z_a = 1)
path$truth <- 0.8^path$horizon * true_g(1)
path
plot_irf(path, x = "horizon", xlab = "Horizon h", ylab = "g_h(1)")


# ---- Step 6. Contrast between two states: g_h(1.5) - g_h(0) -----------
contrast <- pointwise_path(fits, z_a = 1.5, z_b = 0)
contrast$truth <- 0.8^contrast$horizon * (true_g(1.5) - true_g(0))
contrast
plot_irf(contrast, x = "horizon", xlab = "Horizon h", ylab = "g_h(1.5) - g_h(0)")


# ---- Step 7. Contrast between percentiles: 95th minus median ----------
z95 <- quantile(dat$Z, 0.95)
z50 <- quantile(dat$Z, 0.50)
pointwise_path(fits, z_a = z95, z_b = z50)


# ---- Step 8. Save the results ----------------------------------------
saveRDS(list(fits = fits, linear = linear, dat = dat, true_g = true_g),
        "output/quadratic_results.rds")
