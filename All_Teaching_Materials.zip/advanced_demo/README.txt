CAUSAL STATE-DEPENDENT LOCAL PROJECTIONS -- R DEMOS
DG ECFIN practical training, 19 November 2026

1. BEFORE CLASS (please do this at least a week ahead)
   a) Install the packages:
        install.packages(c("mvtnorm", "glmnet", "ggplot2"))
   b) Set the working directory to this R_code_demo folder and run
        source("00_check_install.R")
      It should end with "ALL CHECKS PASSED" and show a small plot.
   c) If packages cannot be installed (firewall, proxy, no admin rights),
      ask IT support, or use a cloud R environment (e.g. Posit Cloud):
      upload this folder there and run the same check.
   This download supplies code without saved-result caches. Run
   01_demo_quadratic.R and 02_demo_cubic.R first to create output/ results.

2. IN CLASS
   Set the working directory to this R_code_demo folder, then run
   section by section:
     01_demo_quadratic.R   true response g(z) = 1 - z^2 (hump-shaped)
     02_demo_cubic.R       true response g(z) = 0.5z + 0.3z^2 - 0.25z^3
     03_exercises.R        uses the saved cubic results
     04_your_data_template.R   from a raw, unbalanced panel to results:
                               copy it and replace Step 0 with your data
   Each script starts with source("00_setup.R").
   Each demo takes about half a minute.

3. WHAT EACH DEMO DOES
   Step 1  simulate a panel with a known response
   Step 2  estimate g_h(z), h = 0,...,12, with gauss_bootstrap_ucb()
   Step 3  plot the state curve at fixed h, with a UNIFORM band over z
   Step 4  (Demo 1) compare with the standard linear-interaction LP
   Step 5  plot the path over h at a fixed state z, with POINTWISE CIs
   Step 6  plot a state contrast g_h(z_a) - g_h(z_b), with POINTWISE CIs
   (Demo 1 also shows a 95th-minus-median percentile contrast.)

4. FILES
   functions/uniform_bands_FE.R     paper code: gauss_bootstrap_ucb()
   functions/simulate_DGPs.R        paper code: simulate_DGP_paranhos()
   functions/NL_helper_functions.R  paper code: evaluate_sieve_basis()
   functions/course_helpers.R       course code, short helpers:
     Preparing your own panel
       complete_panel(dat, id_var, time_var) balanced layout, NA-filled
       check_panel(dat)                       balanced-panel check
       lag_by_unit(dat, var, k)               lag (k>0) / lead (k<0) by unit
       add_cumulative_outcomes(dat, y, H)     y_{t+h} - y_{t-1}, h = 0..H
       fit_by_horizon(dat, y_prefix, H, ...)  one H = 0 fit per outcome
     Reading the results
       band_at_horizon(fits, h)               curve + uniform band at h
       pointwise_path(fits, z_a, z_b = NULL)  path or contrast over h
     Plots
       plot_irf(table, x)                     plot any of the tables
       plot_compare(list(A = t1, B = t2))     overlay several fits
   See "CHANGES FROM THE PAPER CODE" below.

5. THINGS TO REMEMBER
   - Notation follows the paper: row (i,t) holds Y_it, X_t, the state
     Z_i,t-1 and controls W_i,t-1 (here Y_lag = Y_i,t-1).
   - The estimator needs a balanced panel with time labelled 1,...,T,
     and builds Y_{t+h} itself from the column Y. For real data, use
     complete_panel(); missing slots become NA rows, which are dropped.
   - Date the state and controls BEFORE the shock: if your state is
     recorded at t, use lag_by_unit(dat, "state", 1).
   - For a cumulative outcome y_{t+h} - y_{t-1}, build the outcomes with
     add_cumulative_outcomes() and estimate with fit_by_horizon(); this
     passes H = 0 so the outcome is not led a second time.
   - Scale the shock so that one unit is the shock you want to report,
     e.g. X / 0.25 for a 25 bp shock measured in percentage points.
   - J_method defaults to "pcv": AIC over J = 4,...,20, as in the paper.
     The demos instead fix J = 4 with J_method = "manual", J = 4.
     With large panels AIC can select a large J; it searches up to 20
     candidates at every horizon, so it is slower than a fixed J.
   - A band at horizon h is uniform over z for that h only.
     Paths and contrasts over h are pointwise, horizon by horizon.
   - The inference domain is the grid Z_grid; the demos use the middle
     98% of observed states. Report it.
   - fe = TRUE removes unit means; it does not add time effects.

6. CHANGES FROM THE PAPER CODE
   - simulate_DGPs.R: the "quadratic" option now uses the hump-shaped
     g(z) = 1 - z^2 (an inverted U with maximum 1 at z = 0). Demo 1 uses
     the same truth: g_h(z) = 0.8^h (1 - z^2). The true response at z = 1
     is zero at every horizon; the true contrast g_h(1.5) - g_h(0) is
     -2.25 * 0.8^h.
   - uniform_bands_FE.R: the default J_method is now "pcv" (was "cv"),
     so a call without J_method selects J by AIC, as in the paper.
     Nothing else in the estimator or inference code is changed.
   - NL_helper_functions.R is an unchanged copy.
