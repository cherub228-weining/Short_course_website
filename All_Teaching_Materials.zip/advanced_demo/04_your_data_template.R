# =====================================================================
# 04_your_data_template.R  --  from a raw panel to results
# Replace Step 0 with your own data; the other steps stay the same.
# The example data mimic a typical raw panel: unit codes, quarterly dates,
# missing rows, a state recorded at its own date, a shock in percentage
# points. Because they are simulated, we can check the answer.
# =====================================================================
source("00_setup.R")


# ---- Step 0. Raw data (replace with your own, e.g. read.csv) ---------
sim <- simulate_DGP_paranhos(
  N = 80, T = 240, H = 1, g_spec = "quadratic",
  theta = 0, alpha_mode = "zero", seed = 19020, make_pdata = FALSE, out = "panel"
)
quarters <- seq(as.Date("1965-01-01"), by = "quarter", length.out = 240)
raw <- data.frame(
  unit    = sprintf("U%02d", sim$panel_df$id),
  quarter = quarters[sim$panel_df$time],
  y       = sim$panel_df$Y,           # outcome
  shock   = sim$panel_df$X,           # aggregate shock, percentage points
  state   = sim$panel_df$Z_lead1      # state, recorded at the end of each quarter
)
set.seed(1)
raw <- raw[-sample(nrow(raw), round(0.05 * nrow(raw))), ]   # 5% of rows missing
head(raw)


# ---- Step 1. Balanced layout: one row per unit and quarter -----------
dat <- complete_panel(raw, id_var = "unit", time_var = "quarter")
check_panel(dat)


# ---- Step 2. Date the variables as in the LP --------------------------
dat$Z     <- lag_by_unit(dat, "state", 1)   # state Z_{i,t-1}, known before the shock
dat$y_lag <- lag_by_unit(dat, "y", 1)       # control W_{i,t-1}
dat$X     <- dat$shock / 0.25               # one unit of X = a 25 bp shock
# (For a 25 bp CUT, multiply the estimated responses by -1.)


# ---- Step 3. Cumulative outcomes  y_{i,t+h} - y_{i,t-1} ----------------
H   <- 8
dat <- add_cumulative_outcomes(dat, "y", H)   # columns y_cum0, ..., y_cum8


# ---- Step 4. Estimate, one horizon at a time ---------------------------
z_grid <- seq(quantile(dat$Z, 0.01, na.rm = TRUE),
              quantile(dat$Z, 0.99, na.rm = TRUE), length.out = 101)
set.seed(19120)
fits <- fit_by_horizon(
  dat, y_prefix = "y_cum", H = H,
  X_var = "X", Z_var = "Z", W_vars = "y_lag",
  basis = "spline", J_method = "pcv",          # J chosen by AIC, as in the paper
  Z_grid = z_grid, inference = "uniform", alpha = 0.05
)
sapply(fits, `[[`, "J_selected")              # selected J at each horizon


# ---- Step 5. Results ---------------------------------------------------
curve0 <- band_at_horizon(fits, h = 0)
curve0$truth <- 0.25 * (1 - curve0$z^2)       # known here only because data are simulated
plot_irf(curve0, x = "z", xlab = "State z", ylab = "Response to a 25 bp shock")

z95 <- quantile(dat$Z, 0.95, na.rm = TRUE)
z50 <- quantile(dat$Z, 0.50, na.rm = TRUE)
contrast <- pointwise_path(fits, z_a = z95, z_b = z50)
contrast
plot_irf(contrast, x = "horizon", xlab = "Horizon h", ylab = "95th minus median")


# ---- Step 6. Save tables for your report -------------------------------
write.csv(curve0,   "output/your_data_curve_h0.csv",   row.names = FALSE)
write.csv(contrast, "output/your_data_contrast.csv",   row.names = FALSE)
