# =====================================================================
# Hands-on exercises. Uses the saved results of Demo 2 (cubic).
# =====================================================================
source("00_setup.R")
res    <- readRDS("output/cubic_results.rds")
fits   <- res$fits
dat    <- res$dat
true_g <- res$true_g


# ---- Exercise 1. Response path at z = 0 instead of z = 1 --------------
# No re-estimation needed: the fit stores b_hat and V_hat.
pointwise_path(fits, z_a = 0)


# ---- Exercise 2. Reverse the contrast ---------------------------------
# The estimate changes sign; the standard error is unchanged.
pointwise_path(fits, z_a = 1.5, z_b = 0)[1, ]
pointwise_path(fits, z_a = 0, z_b = 1.5)[1, ]


# ---- Exercise 3. 90% instead of 95% pointwise intervals ---------------
contrast90 <- pointwise_path(fits, z_a = 1.5, z_b = 0, alpha = 0.10)
plot_irf(contrast90, x = "horizon", xlab = "Horizon h")
# (A uniform band at a new level needs a new call to gauss_bootstrap_ucb.)


# ---- Exercise 4. A linear specification versus the sieve --------------
# basis = "polynomial" with J = 2 means g_h(z) = alpha_h + beta_h z: the standard
# linear-interaction LP. Compare it with the J = 4 spline at h = 0.
z_grid <- fits[["h=0"]]$Z_grid
set.seed(19113)
linear_fit <- gauss_bootstrap_ucb(
  data = dat, Y_var = "Y", X_var = "X", Z_var = "Z", W_vars = "Y_lag",
  basis = "polynomial", J_method = "manual", J = 2,
  H = 0, Z_grid = z_grid, inference = "uniform", alpha = 0.05
)
linear0 <- band_at_horizon(linear_fit, h = 0)
linear0$truth <- true_g(linear0$z)
plot_irf(linear0, x = "z", xlab = "State z", ylab = "Linear fit of g_0(z)")


# ---- Exercise 5. Let AIC choose J -------------------------------------
# J_method = "pcv" with pcv_metric = "aic" (now the defaults) minimises
# AIC_h(J) over J = 4, ..., 20, as in the paper.
set.seed(19114)
aic_fit <- gauss_bootstrap_ucb(
  data = dat, Y_var = "Y", X_var = "X", Z_var = "Z", W_vars = "Y_lag",
  basis = "spline", J_method = "pcv", pcv_metric = "aic",
  H = 0, Z_grid = z_grid, inference = "uniform", alpha = 0.05
)
aic_fit[["h=0"]]$J_selected
aic0 <- band_at_horizon(aic_fit, h = 0)
aic0$truth <- true_g(aic0$z)
plot_irf(aic0, x = "z", xlab = "State z", ylab = "AIC fit of g_0(z)")


# ---- Optional. Unit fixed effects -------------------------------------
# Simulate data WITH unit effects, then use the within estimator (fe = TRUE).
# sim_fe <- simulate_DGP_paranhos(N = 80, T = 240, H = 0, g_spec = "cubic",
#   theta = 0, alpha_mode = "normal", seed = 19013,
#   make_pdata = FALSE, out = "panel")
# fe_fit <- gauss_bootstrap_ucb(
#   data = sim_fe$panel_df, Y_var = "Y", X_var = "X", Z_var = "Z",
#   W_vars = "Y_lag", basis = "spline", J_method = "manual", J = 4,
#   H = 0, inference = "uniform", alpha = 0.05, fe = TRUE)
