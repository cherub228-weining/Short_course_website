# =====================================================================
# Demo 2: cubic state dependence, g(z) = 0.5 z + 0.3 z^2 - 0.25 z^3
# Same workflow as Demo 1. Only the true response changes.
# =====================================================================
source("00_setup.R")


# ---- Step 1. Simulate -------------------------------------------------
H      <- 12
true_g <- function(z) 0.5 * z + 0.3 * z^2 - 0.25 * z^3

sim <- simulate_DGP_paranhos(
  N = 80, T = 240, H = H, g_spec = "cubic",
  theta = 0, alpha_mode = "zero",
  seed = 19012, make_pdata = FALSE, out = "panel"
)
dat <- sim$panel_df[, c("id", "time", "Y", "X", "Z", "Y_lag")]
# Row (i,t): Y = Y_it, X = X_t, Z = Z_i,t-1, Y_lag = Y_i,t-1
check_panel(dat)


# ---- Step 2. Estimate -------------------------------------------------
z_grid <- seq(quantile(dat$Z, 0.01), quantile(dat$Z, 0.99), length.out = 101)

set.seed(19112)
fits <- gauss_bootstrap_ucb(
  data = dat, Y_var = "Y", X_var = "X", Z_var = "Z",
  W_vars = "Y_lag", basis = "spline", J_method = "manual", J = 4,
  H = H, Z_grid = z_grid, inference = "uniform", alpha = 0.05
)


# ---- Step 3. State curves at h = 0 and h = 8 (uniform bands) ----------
curve0 <- band_at_horizon(fits, h = 0)
curve0$truth <- true_g(curve0$z)
plot_irf(curve0, x = "z", xlab = "State z", ylab = "g_0(z)")

curve8 <- band_at_horizon(fits, h = 8)
curve8$truth <- 0.8^8 * true_g(curve8$z)
plot_irf(curve8, x = "z", xlab = "State z", ylab = "g_8(z)")


# ---- Step 4. Path at z = 1 and contrast g_h(1.5) - g_h(0) (pointwise) --
path <- pointwise_path(fits, z_a = 1)
path$truth <- 0.8^path$horizon * true_g(1)
plot_irf(path, x = "horizon", xlab = "Horizon h", ylab = "g_h(1)")

contrast <- pointwise_path(fits, z_a = 1.5, z_b = 0)
contrast$truth <- 0.8^contrast$horizon * (true_g(1.5) - true_g(0))
plot_irf(contrast, x = "horizon", xlab = "Horizon h", ylab = "g_h(1.5) - g_h(0)")


# ---- Step 5. Save -----------------------------------------------------
saveRDS(list(fits = fits, dat = dat, true_g = true_g),
        "output/cubic_results.rds")
