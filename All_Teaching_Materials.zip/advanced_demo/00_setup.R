# =====================================================================
# 00_setup.R  --  run once at the start of each R session
# Set the working directory to the R_code_demo folder first.
# =====================================================================

# Packages (install once, before class):
# install.packages(c("mvtnorm", "glmnet", "ggplot2"))
library(ggplot2)

# Paper functions; the simulator quadratic option is adapted to g(z)=1-z^2
source("functions/simulate_DGPs.R")        # simulate_DGP_paranhos(): simulated panel
source("functions/uniform_bands_FE.R")     # gauss_bootstrap_ucb(): estimation + inference
source("functions/NL_helper_functions.R")  # evaluate_sieve_basis(): basis phi(z) of a fit

# Small course helpers: tables and plots
source("functions/course_helpers.R")

dir.create("output", showWarnings = FALSE)
